# MediSentinel hardware build — staged and reversible

**Current status, 8 November 2026:** Saif compiled/uploaded both sketches and verified secure USB telemetry with ESP32 COM3 and NodeMCU ESP-12E COM8 at 115200 baud. The observed gateway uses port 5004. After serial framing repair, each replay/altered/spoof test produced its expected rejection twice through the actual test-node USB stream. LEDs, the physical button, OLED and buzzer remain unwired/unverified. Follow the wiring stages below next; compilation/provisioning sections are for reference or a fresh setup. All vital signs are simulated. See `evidence/HARDWARE_RESULTS.md` for completed and pending checks.

## 1. Identify the boards before connecting jumpers

This pin map applies **only to a classic ESP32 / ESP32-WROOM development board** exposing GPIO25, GPIO26, GPIO27, GPIO21, GPIO22 and GND. It does not automatically apply to ESP32-C3/S3/C6 or other variants. Send a clear photo of the printed board labels, both sides if needed, before following the pin map. Use the printed **GPIO number**, not a pin's physical position. Header pins must already be fitted for a solder-free build.

For the second board, verify that ESP-12E is mounted on a **NodeMCU-style development board with a USB socket and voltage regulator**. A bare ESP-12E radio module has no USB connector and needs a suitable programmer, regulated supply and boot connections; do not wire it directly to USB or improvise a 5 V supply. With a USB-equipped development board, connect its own USB cable to the laptop; no wires are needed between the two boards. [1][3]

The smallest complete hardware demo needs the ESP32, two LEDs, two resistors, one button, breadboard and jumpers. The second board is a controlled USB attack injector. OLED and buzzer are optional additions after the basic demonstration works.

## 2. Work with USB unplugged

Disconnect the ESP32 USB cable before moving any wires. USB is the only board power source. Never connect an external supply to 5V/VIN or 3V3 while USB is connected. Use the **3V3** pin for a compatible OLED; never feed 5 V into an ESP32 GPIO. Do not short 3V3 to GND. The board guide lists USB, 5 V and 3V3 power as mutually exclusive options. [1]

Breadboard groups of five holes usually share one connection; the center trench separates the two halves. Some power rails are split halfway. Do not assume that every hole in a long rail is connected. Wire the ESP32 GND to a ground rail first. Use jumpers to reach GPIOs if the board is too wide to leave usable breadboard holes.

## 3. First connection: red LED

Use a separate **330 ohm resistor** for each LED. A typical red LED with approximately 2 V forward drop draws about `(3.3 - 2.0)/330 = 3.9 mA`; this is a design estimate, not a measured current. A 470 ohm or 1 kohm resistor is also acceptable and dimmer. Never connect an LED directly between GPIO and ground.

| Part | Connection | Note |
|---|---|---|
| ESP32 GND | Breadboard ground rail | Common return for this board's peripherals |
| GPIO25 | One end of red LED's 330 ohm resistor | GPIO label may read 25 or IO25 |
| Other resistor end | Red LED anode | Usually longer leg |
| Red LED cathode | Ground rail | Usually shorter leg / flat edge |

The resistor and LED must form one series path. Do not place both LED legs in the same connected breadboard row. If it does not light during a known alert, unplug USB before reversing the LED. Saif's board labels must first match the classic ESP32 pin map. GPIO25 and GPIO26 are documented output-capable pins on the classic ESP32-DevKitC. [1]

## 4. Add green LED and physical button

| Part | Connection | Firmware behavior |
|---|---|---|
| GPIO26 | 330 ohm resistor, then green LED anode | Green when authenticated host feedback has arrived within 5 seconds and no alert |
| Green LED cathode | Ground rail | Never omit its own resistor |
| Button terminal A | GPIO27 | Firmware uses `INPUT_PULLUP` |
| Button terminal B, opposite electrical contact | Ground rail | Press connects GPIO27 to ground |

A four-legged tactile button usually has two permanently connected pairs; use one terminal from each pair, often straddling the breadboard center trench. Check with a meter if available or send a photo before power. Do not wire the button to 3V3: the internal pull-up provides the idle high level. ESP32's GPIO API supports `INPUT_PULLUP`. [4]

Button behavior: press once to enable a **15-second local simulated alert**; press again to end it early. The red LED turns on immediately and telemetry changes to simulated HR about 130 BPM and SpO2 89%. The JSON readings are authenticated with the same signing protocol. The device's button event is a UI hint; it is not an authenticated security finding. In a connected host, the dashboard keeps recent ML flags visible for five seconds and threshold alerts while fresh readings exceed the example limits; its clear control clears transient alerts.

No jumper connects the ESP32 to the ESP8266. Their USB connections give the host the two serial channels. This is an intentionally local adversarial test fixture; it does not implement Wi-Fi spoofing, deauthentication, or hospital-network interception.

## 5. Compile and upload ESP32 firmware - reference / fresh setup

1. First save your original `.ino` sketch in a backup folder. Before replacing its firmware, you may use `python medisentinel_secure.py --legacy-port COM3` to view current unsigned telemetry in explicitly labelled legacy mode. Close the Flask serial dashboard and all other serial readers so COM3 is free. Close Arduino Serial Monitor before starting the new dashboard.
2. Install **esp32 by Espressif Systems** in Arduino IDE Boards Manager if not already present. Keep the board selection that successfully uploaded to your existing ESP32; for a confirmed generic classic ESP32-WROOM board this is usually **ESP32 Dev Module**.
3. In Library Manager install **ArduinoJson, major version 7**. The sketch uses the v7 `JsonDocument` API. [5]
4. Run `python setup_lab.py` from the project folder. It produces the local host configuration and `firmware/MediSentinel_ESP32/secrets.h`. The ESP32 and host must use the **same key as ASCII text**, without hex-decoding it. The second board receives no key.
5. Open `firmware/MediSentinel_ESP32/MediSentinel_ESP32.ino`. Keep `ENABLE_OLED 0` and `ENABLE_BUZZER 0` initially. Confirm the adjacent `secrets.h` tab exists.
6. Choose the ESP32's port, currently COM3. Click **Verify** first and record any compiler errors. Click **Upload** after successful verification. If your board requires it, hold BOOT only when the IDE shows Connecting, then release when writing begins.
7. Run `python medisentinel_secure.py --port COM3` from the project folder; open `http://127.0.0.1:5003`. Startup logs may appear; the device deliberately waits for an authenticated SESSION command before emitting signed telemetry. No values in Serial Monitor alone is expected until a valid host session is established.
8. Confirm rising packet counts, `simulated:true`, successful authentication and green LED. Test the dashboard's manual red alert, then the physical button, then clear. Record which checks actually pass in `evidence/HARDWARE_RESULTS.md`; do not replace pending claims with assumed results.

The firmware accepts bounded newline-delimited input. Its loop uses elapsed-time checks and button debounce rather than blocking delays. Repeated SESSION commands for the current nonce preserve the packet counter; a new nonce starts a new sequence. The host should use a fresh session after reset/reconnection. Host ALARM feedback is HMAC-authenticated and expires after five seconds, while a local button alarm can finish its own 15-second interval.

## 6. Compile and connect ESP8266 authorized test node

1. Confirm a USB-equipped NodeMCU ESP-12E development board. Install **esp8266 by ESP8266 Community** in Boards Manager. If needed, add the official package index URL `https://arduino.esp8266.com/stable/package_esp8266com_index.json` in Arduino IDE settings. [3][6]
2. Select **NodeMCU 1.0 (ESP-12E Module)** for a matching NodeMCU board. Select its port; it will generally differ from COM3. The observed laptop uses COM8; on a new machine use Device Manager or Arduino's port menu to identify it.
3. Open `firmware/MediSentinel_ESP8266/MediSentinel_ESP8266.ino`. Install ArduinoJson 7 if needed. Verify and upload; then close Serial Monitor.
4. Run `python medisentinel_secure.py --port COM3 --attacker-port COM8 --http-port 5004`, substituting the actual second-board port on a new setup; open `http://127.0.0.1:5004`. Wait for both ports and one accepted medical-device packet. The host forwards one observed signed message with `CAPTURE <JSON>` so the test node can retain it.
5. Use the dashboard attack controls to request **replay**, **altered**, or **spoof**. Each asks the ESP8266 to emit a controlled test message on its own USB serial channel. Confirm the event explicitly identifies the hardware node as the source.

| Test node command | Actual node behavior | Expected host decision |
|---|---|---|
| `CAPTURE <signed JSON>` | Stores the observed packet; does not learn the key | No telemetry ingestion from this acknowledgement |
| `ATTACK replay` | Emits the captured JSON exactly | Reject previously seen sequence (or expired session after reset) |
| `ATTACK altered` | Changes HR to 149/150, leaves signature unchanged | Reject message authentication |
| `ATTACK spoof` | Changes device ID to FORGED-DEVICE-99 | Reject unknown identity |

If a test is performed using the software test injector, call it a **software test**. Only call it an ESP8266 hardware test after the board emits the packet and the host records it. Replay rejection assumes the original captured message was accepted before it was resent. An adversary who obtains the signing key can create valid messages; HMAC cannot identify a compromised signer.

## 7. Optional OLED — only after identifying its controller

This version supports a **128 x 64 SSD1306 four-pin I2C OLED**, supported in the supplied source but not physically tested, with address `0x3C`. A 0.96-inch display may use another controller or geometry. Confirm its markings and 3.3 V compatibility; use the printed labels because pin order differs across modules. Do not use this map for a SPI display. Most breakout modules include I2C pull-ups; verify that these pull up to 3.3 V, not 5 V. Espressif documents SDA21/SCL22 for generic classic ESP32 and requires SDA/SCL pull-ups. [2]

| OLED printed label | Confirmed classic ESP32 pin |
|---|---|
| GND | Ground rail |
| VCC / VDD | 3V3, only for a module rated for 3.3 V |
| SDA | GPIO21 |
| SCL / SCK (I2C module) | GPIO22 |

Install **Adafruit SSD1306** and **Adafruit GFX** via Arduino Library Manager, with dependencies. Set `ENABLE_OLED 1` in the ESP32 sketch and upload. The display must show **SIMULATED VITALS**. If blank, return `ENABLE_OLED` to 0 while troubleshooting the controller/address/wiring; telemetry and LEDs should still work. An `0x3D` module needs the address changed in the source. SH1106 modules require another driver. [7]

## 8. Optional buzzer — identify type first

Keep `ENABLE_BUZZER 0` until its type, voltage and drive circuit are known. A loose two-pin buzzer may draw more current than a GPIO can safely supply; do not wire an unidentified buzzer straight to GPIO32. Do not infer current limits from its physical size.

This firmware's optional buzzer output is a **pulsed logic signal for a verified 3.3 V active buzzer module with its own transistor driver and active-high signal input**. For that specific module, power it from 3V3 and GND according to its datasheet, connect its signal input to GPIO32, confirm the module's total current is within the board's remaining 3.3 V regulator capacity, then set `ENABLE_BUZZER 1`. It will pulse for approximately 160 ms every 800 ms during an alert. An active-low module needs the output logic changed. A passive piezo requires a tone waveform and is not supported by this default digital drive. A two-pin active buzzer normally needs a suitable external transistor/driver; those extra parts are not assumed available.

Send the buzzer's printed markings and a photo before choosing its wiring. The deadline-safe build can demonstrate a prominent visual alert and red LED without a physical buzzer.

## 9. Optional enclosure

Ask your friend to measure the actual breadboard, ESP32 and USB plug clearances before printing. Use a removable cover, cable opening, ventilation, strain relief that does not pinch USB cables, and separate LED/button access. Keep the ESP antenna area clear of metal. Do not force or glue live wires into place. A simple open tray with breadboard adhesive is adequate for the video. No dimension-specific enclosure file has been supplied because board and breadboard sizes are unverified.

## Sources checked 8 November 2026

[1] Espressif, **ESP32-DevKitC V4 User Guide** — GPIO headers, USB power, power-source exclusivity: https://docs.espressif.com/projects/esp-dev-kits/en/latest/esp32/esp32-devkitc/user_guide.html

[2] Espressif, **Arduino-ESP32 I2C API** — generic classic ESP32 SDA21/SCL22 and pull-ups: https://docs.espressif.com/projects/arduino-esp32/en/latest/api/i2c.html

[3] ESP8266 Arduino Core, **Boards** — NodeMCU versus bare modules, USB-serial and power requirements: https://arduino-esp8266.readthedocs.io/en/stable/boards.html

[4] Espressif, **Arduino-ESP32 GPIO API** — `INPUT_PULLUP`, outputs and reads: https://docs.espressif.com/projects/arduino-esp32/en/latest/api/gpio.html

[5] ArduinoJson, **Version 7 deserialization tutorial**: https://arduinojson.org/v7/tutorial/deserialization/

[6] ESP8266 Arduino Core, **Installing with Boards Manager**: https://arduino-esp8266.readthedocs.io/en/stable/installing.html

[7] Adafruit, **Adafruit SSD1306 library**: https://github.com/adafruit/Adafruit_SSD1306
