"""Record actual laptop tests and a non-destructive COM3 probe. No upload."""
from pathlib import Path
import datetime
import json
import math
import platform
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parent


def serial_probe(port="COM3", seconds=7):
    import serial
    from serial.tools import list_ports
    result = {"port": port, "legacy_json_observed": False,
              "devices": [{"port": p.device, "description": p.description} for p in list_ports.comports()]}
    try:
        # Opens only if free. Opening a serial port can reset common ESP32 boards;
        # no bytes/commands/firmware are written by this probe.
        with serial.Serial(port, 115200, timeout=.5, write_timeout=.5) as device:
            stop_at = time.monotonic() + seconds
            while time.monotonic() < stop_at:
                line = device.read_until(b"\n", 2049)
                if not line or len(line) > 2048:
                    continue
                try:
                    packet = json.loads(line)
                except (ValueError, UnicodeDecodeError):
                    continue
                if (isinstance(packet, dict) and packet.get("simulated") is True and
                        all(type(packet.get(k)) in (int, float) and low <= packet[k] <= high and math.isfinite(packet[k])
                            for k, low, high in (("heart_rate_bpm", 0, 300), ("spo2_percent", 0, 100)))):
                    result["legacy_json_observed"] = True
                    result["note"] = "Actual USB telemetry JSON observed; authenticity and measurements are unverified."
                    break
            else:
                result["note"] = "Port opened, but no old-format JSON was observed during the probe."
    except (serial.SerialException, OSError) as exc:
        result["note"] = "Port unavailable or occupied. Existing programs were left running."
        result["error"] = str(exc)
    return result


def main():
    target = ROOT / "evidence/laptop"
    target.mkdir(parents=True, exist_ok=True)
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    with (target / "unit_tests.txt").open("w", encoding="utf-8") as output:
        result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    from ml_detector import MLDetector
    detector = MLDetector()
    scoring = detector.score(110, 94, {"heart_rate_bpm": 77, "spo2_percent": 97})
    print(f"Actual laptop tests: {result.testsRun} run; {len(result.failures)} failures; {len(result.errors)} errors; {len(result.skipped)} skipped.", flush=True)
    observed = serial_probe()
    record = {
        "checked_local": datetime.datetime.now().astimezone().isoformat(), "platform": platform.platform(),
        "python": platform.python_version(), "tests_run": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
        "model_available": detector.available, "signed_anomaly_scoring_example": scoring,
        "serial_probe": observed,
        "arduino_compile_verified": False, "firmware_uploaded": False,
        "note": "This file describes only checks actually executed by laptop_check.py. No physical outputs are verified."
    }
    (target / "laptop_verification.json").write_text(json.dumps(record, indent=2, allow_nan=False), encoding="utf-8")
    print("COM3: " + observed.get("note", "Unknown"), flush=True)
    if not result.wasSuccessful() or not detector.available:
        raise RuntimeError("Laptop checks did not all pass or the model was unavailable; read evidence/laptop.")


if __name__ == "__main__":
    main()
