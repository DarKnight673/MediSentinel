"""Strict simulated-telemetry protocol. No clinical decisions are made here."""
import hashlib
import hmac
import re
import secrets

DEVICE_ID = "MEDI-ESP32-01"
FIELDS = {"device_id", "session", "packet", "heart_rate_bpm", "spo2_percent", "simulated", "mac"}


def tag(key, text):
    return hmac.new(key.encode("ascii"), text.encode("ascii"), hashlib.sha256).hexdigest()


def canonical(p):
    return f"MS1|{p['device_id']}|{p['session']}|{p['packet']}|{p['heart_rate_bpm']}|{p['spo2_percent']}|1"


def signed_packet(key, session, packet, hr=77, spo2=97, device_id=DEVICE_ID):
    p = dict(device_id=device_id, session=session, packet=packet,
             heart_rate_bpm=hr, spo2_percent=spo2, simulated=True)
    p["mac"] = tag(key, canonical(p))
    return p


def session_command(key, session):
    return f"SESSION {session} {tag(key, 'MS1-SESSION|' + session)}\n"


def alarm_command(key, session, active):
    value = int(bool(active))
    return f"ALARM {session} {value} {tag(key, f'MS1-ALARM|{session}|{value}')}\n"


class Verifier:
    def __init__(self, key):
        self.key = key
        self.new_session()

    def new_session(self):
        self.session = secrets.token_hex(16)
        self.last_packet = 0
        return self.session

    def verify(self, p):
        if not isinstance(p, dict) or set(p) != FIELDS:
            return False, "schema"
        if p["device_id"] != DEVICE_ID:
            return False, "unknown_device"
        if not isinstance(p["session"], str) or not re.fullmatch(r"[0-9a-f]{32}", p["session"]):
            return False, "schema"
        for field, low, high in (("packet", 1, 4294967295), ("heart_rate_bpm", 0, 300), ("spo2_percent", 0, 100)):
            if type(p[field]) is not int or not low <= p[field] <= high:
                return False, "schema"
        if p["simulated"] is not True or not isinstance(p["mac"], str) or not re.fullmatch(r"[0-9a-f]{64}", p["mac"]):
            return False, "schema"
        if not hmac.compare_digest(tag(self.key, canonical(p)), p["mac"]):
            return False, "bad_mac"
        if p["session"] != self.session:
            return False, "stale_session"
        if p["packet"] <= self.last_packet:
            return False, "replay"
        self.last_packet = p["packet"]
        return True, "authenticated"
