"""Security, HTTP and simulated USB-serial integration tests; no physical board."""
import copy
import json
import math
import os
from pathlib import Path
import select
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from security import Verifier, canonical, signed_packet, tag, session_command, alarm_command
from medisentinel_secure import BoundedLineFramer, Engine, SerialLab, create_app, demo_rules

KEY = "ab" * 32


class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.v = Verifier(KEY)

    def packet(self, n=1, **kwargs):
        return signed_packet(KEY, self.v.session, n, **kwargs)

    def test_valid_canonical_hmac_and_sequence_gaps(self):
        p = self.packet()
        self.assertEqual(canonical(p), f"MS1|MEDI-ESP32-01|{self.v.session}|1|77|97|1")
        self.assertEqual(self.v.verify(p), (True, "authenticated"))
        self.assertEqual(self.v.verify(self.packet(100)), (True, "authenticated"))

    def test_replays_and_older_counters(self):
        self.v.verify(self.packet(5))
        self.assertEqual(self.v.verify(self.packet(5)), (False, "replay"))
        self.assertEqual(self.v.verify(self.packet(4)), (False, "replay"))
        self.assertEqual(self.v.last_packet, 5)

    def test_altered_telemetry_does_not_advance_counter(self):
        p = self.packet()
        p["heart_rate_bpm"] = 110
        self.assertEqual(self.v.verify(p), (False, "bad_mac"))
        self.assertEqual(self.v.last_packet, 0)
        self.assertTrue(self.v.verify(self.packet())[0])

    def test_unknown_device_rejected(self):
        self.assertEqual(self.v.verify(self.packet(device_id="FORGED-DEVICE")), (False, "unknown_device"))

    def test_new_session_rejects_valid_old_signature(self):
        old_packet = self.packet()
        old_session = self.v.session
        self.v.new_session()
        self.assertNotEqual(old_session, self.v.session)
        self.assertEqual(self.v.verify(old_packet), (False, "stale_session"))
        self.assertTrue(self.v.verify(self.packet())[0])

    def test_schema_types_bounds_and_nonfinite(self):
        cases = [("packet", True), ("packet", 1.0), ("packet", 0), ("packet", 2**32),
                 ("heart_rate_bpm", float("nan")), ("heart_rate_bpm", float("inf")),
                 ("heart_rate_bpm", 301), ("spo2_percent", -1), ("spo2_percent", 101),
                 ("simulated", "true"), ("simulated", False), ("session", "bad"), ("mac", "BAD")]
        for key, value in cases:
            with self.subTest(field=key, value=value):
                p = self.packet()
                p[key] = value
                self.assertEqual(self.v.verify(p), (False, "schema"))
        p = self.packet(); p["extra"] = "x"
        self.assertEqual(self.v.verify(p), (False, "schema"))
        self.assertEqual(self.v.verify([]), (False, "schema"))

    def test_command_authentication_domain_separation(self):
        nonce = self.v.session
        self.assertEqual(session_command(KEY, nonce), f"SESSION {nonce} {tag(KEY, 'MS1-SESSION|' + nonce)}\n")
        self.assertEqual(alarm_command(KEY, nonce, True), f"ALARM {nonce} 1 {tag(KEY, 'MS1-ALARM|' + nonce + '|1')}\n")
        self.assertNotEqual(tag(KEY, "MS1-SESSION|" + nonce), tag(KEY, "MS1-ALARM|" + nonce + "|1"))


class SpyDetector:
    available = True
    info = {"available": True, "algorithm": "test spy (not an ML experiment)"}

    def __init__(self):
        self.calls = []

    def score(self, hr, spo2, previous):
        self.calls.append((hr, spo2, previous))
        return {"available": True, "anomaly": hr == 110, "score": .7, "threshold": .5}


class EngineTests(unittest.TestCase):
    def test_rejected_packets_do_not_poison_ml_or_graph(self):
        spy = SpyDetector(); e = Engine(KEY, detector=spy)
        valid = signed_packet(KEY, e.verifier.session, 1)
        self.assertTrue(e.ingest(valid)[0])
        latest = copy.deepcopy(e.latest)
        bad = copy.deepcopy(valid); bad["heart_rate_bpm"] = 110
        self.assertFalse(e.ingest(bad)[0])
        self.assertEqual(e.latest, latest)
        self.assertEqual(len(e.history), 1)
        self.assertEqual(len(spy.calls), 1)
        self.assertEqual(e.snapshot()["counts"]["rejected"], 1)

    def test_manual_overlay_does_not_modify_telemetry(self):
        for mode in ("demo", "secure", "legacy"):
            with self.subTest(mode=mode):
                e = Engine(KEY, mode)
                e.manual_alert()
                self.assertIsNone(e.latest)
                self.assertIn("MANUAL DEMO - operator-triggered", e.snapshot()["alerts"])

    def test_crypto_rule_and_ml_alerts_are_distinct(self):
        e = Engine(KEY, detector=SpyDetector())
        e.ingest(signed_packet(KEY, e.verifier.session, 1, 110, 94))
        self.assertEqual(e.latest["rules"], [])
        self.assertTrue(e.latest["ml"]["anomaly"])
        self.assertIn("ML - statistical telemetry anomaly", e.snapshot()["alerts"])
        self.assertNotIn("SECURITY RULE - rejected packet", e.snapshot()["alerts"])

    def test_legacy_is_unverified_and_not_available_in_secure_mode(self):
        p = {"heart_rate_bpm": 77, "spo2_percent": 97, "packet": 1, "simulated": True}
        spy = SpyDetector()
        e = Engine(KEY, "legacy", detector=spy)
        self.assertEqual(e.ingest(p, legacy=True), (True, "legacy_unverified"))
        self.assertFalse(e.latest["authenticated"])
        self.assertIsNone(e.last_capture)
        self.assertEqual(e.counts["unverified"], 1)
        self.assertEqual(spy.calls, [])
        self.assertFalse(e.latest["ml"]["available"])
        self.assertFalse(Engine(KEY, "secure").ingest(p, legacy=True)[0])

    def test_invalid_input_with_audit_logging_does_not_crash(self):
        with tempfile.TemporaryDirectory() as tmp:
            e = Engine(KEY, "legacy", log_dir=tmp)
            for invalid in (float("nan"), float("inf"), True, 10**1000):
                self.assertFalse(e.ingest({"heart_rate_bpm": invalid, "spo2_percent": 97}, legacy=True)[0])
            rows = [json.loads(x) for x in e.log_path.read_text().splitlines()]
            self.assertGreaterEqual(len(rows), 8)
            self.assertIsNone(e.log_error)

    def test_demo_attack_types_are_rejected(self):
        for attack, expected in (("replay", "replay"), ("altered", "bad_mac"), ("spoof", "unknown_device")):
            with self.subTest(attack=attack):
                e = Engine(KEY)
                e.ingest(signed_packet(KEY, e.verifier.session, 1))
                self.assertEqual(e.attack(attack), (False, expected))
                self.assertEqual(len(e.history), 1)

    def test_unavailable_model_is_explicit(self):
        e = Engine(KEY)
        e.ingest(signed_packet(KEY, e.verifier.session, 1))
        self.assertFalse(e.latest["ml"]["available"])
        self.assertFalse(e.snapshot()["ml_info"]["available"])


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.e = Engine(KEY)
        self.app = create_app(self.e)
        self.client = self.app.test_client()
        # Retrieve the actual per-app action token through the index route,
        # without depending on the dashboard's changing HTML layout.
        with patch("medisentinel_secure.render_template", side_effect=lambda *a, **k: k["local_token"]):
            self.token = self.client.get("/").get_data(as_text=True)
        self.headers = {"X-MediSentinel-Local": self.token}

    def test_manual_api_requires_token(self):
        self.assertEqual(self.client.post("/api/action", json={"action": "manual"}).status_code, 403)
        result = self.client.post("/api/action", json={"action": "manual"}, headers=self.headers)
        self.assertEqual(result.status_code, 200)
        self.assertTrue(self.e.snapshot()["alarm"])

    def test_cross_origin_and_untrusted_host_blocked(self):
        headers = {**self.headers, "Origin": "https://example.invalid"}
        self.assertEqual(self.client.post("/api/action", json={"action": "manual"}, headers=headers).status_code, 403)
        self.assertEqual(self.client.get("/api/status", headers={"Host": "evil.invalid"}).status_code, 403)

    def test_api_bad_body_size_and_action(self):
        self.assertEqual(self.client.post("/api/action", json=[], headers=self.headers).status_code, 400)
        self.assertEqual(self.client.post("/api/action", json={"action": "bad"}, headers=self.headers).status_code, 400)
        self.assertEqual(self.client.post("/api/action", data="x" * 3000, content_type="application/json", headers=self.headers).status_code, 413)

    def test_clear_and_model_demo_modes(self):
        self.client.post("/api/action", json={"action": "manual"}, headers=self.headers)
        self.client.post("/api/action", json={"action": "clear"}, headers=self.headers)
        self.assertFalse(self.e.snapshot()["alarm"])
        self.assertEqual(self.client.post("/api/action", json={"action": "ml_demo"}, headers=self.headers).status_code, 200)
        self.e.mode = "secure"
        self.assertEqual(self.client.post("/api/action", json={"action": "ml_demo"}, headers=self.headers).status_code, 409)

    def test_status_no_cache_and_security_headers(self):
        result = self.client.get("/api/status")
        self.assertEqual(result.status_code, 200)
        self.assertEqual(result.headers["Cache-Control"], "no-store")
        self.assertIn("frame-ancestors 'none'", result.headers["Content-Security-Policy"])
        self.assertFalse(result.json["ml_info"]["available"])

    def test_dashboard_template_renders_local_controls(self):
        result = self.client.get("/")
        self.assertEqual(result.status_code, 200)
        self.assertIn(self.token, result.get_data(as_text=True))


class SerialFramingTests(unittest.TestCase):
    def test_partial_record_survives_empty_timeout_chunks(self):
        framer = BoundedLineFramer()
        self.assertEqual(list(framer.feed(b'{"packet":')), [])
        self.assertEqual(list(framer.feed(b"")), [])
        self.assertEqual(list(framer.feed(b"")), [])
        self.assertEqual(list(framer.feed(b'1}\n')), [b'{"packet":1}'])

    def test_limit_and_multiple_records(self):
        framer = BoundedLineFramer(limit=5)
        self.assertEqual(list(framer.feed(b"12345\nA\r\nB\n")), [b"12345", b"A\r", b"B"])
        self.assertEqual(len(framer.pending), 0)

    def test_oversized_record_drains_across_timeouts_and_recovers(self):
        framer = BoundedLineFramer(limit=5)
        self.assertEqual(list(framer.feed(b"123456")), [None])
        self.assertEqual(list(framer.feed(b"")), [])
        self.assertEqual(list(framer.feed(b'{"suffix":1}')), [])
        self.assertEqual(list(framer.feed(b"\nOK\n")), [b"OK"])
        self.assertEqual(len(framer.pending), 0)
        self.assertFalse(framer.discarding)

    def test_oversized_complete_record_then_valid_same_chunk(self):
        framer = BoundedLineFramer(limit=5)
        self.assertEqual(list(framer.feed(b"123456\nOK\n")), [None, b"OK"])


@unittest.skipUnless(os.name == "posix", "POSIX PTY integration only")
class SimulatedSerialIntegrationTests(unittest.TestCase):
    def test_delayed_fragments_and_oversized_suffix_recovery(self):
        import pty
        master, slave = pty.openpty()
        stop = threading.Event()
        engine = Engine(KEY, "secure")
        initial = signed_packet(KEY, engine.verifier.session, 1)
        self.assertTrue(engine.ingest(initial)[0])
        lab = SerialLab(engine, None, None, 115200)
        reader = threading.Thread(target=lab.reader, args=("attacker", os.ttyname(slave), stop), daemon=True)

        def wait_for(predicate, seconds=4):
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                if predicate():
                    return
                time.sleep(.01)
            self.fail("Timed out during serial framing regression: " + repr(engine.snapshot()))

        try:
            reader.start()
            wait_for(lambda: "attacker" in lab.ports)
            altered = copy.deepcopy(initial)
            altered["heart_rate_bpm"] = 110
            encoded = json.dumps(altered).encode()
            midpoint = len(encoded) // 2
            os.write(master, encoded[:midpoint])
            # Intentionally exceed the real pyserial .25-second read timeout.
            time.sleep(.4)
            self.assertEqual(engine.counts["rejected"], 0)
            os.write(master, encoded[midpoint:] + b"\n")
            wait_for(lambda: engine.counts["bad_mac"] == 1)
            self.assertEqual(engine.counts["schema"], 0)

            os.write(master, b"{" + b"X" * 2200)
            wait_for(lambda: engine.counts["schema"] == 1)
            # A timeout must not exit oversized-record draining. Even a valid
            # signed JSON suffix remains part of the oversized bad record.
            time.sleep(.4)
            suffix = json.dumps(signed_packet(KEY, engine.verifier.session, 2)).encode()
            fresh = json.dumps(signed_packet(KEY, engine.verifier.session, 3)).encode()
            os.write(master, suffix + b"\n" + fresh + b"\n")
            wait_for(lambda: engine.latest["packet"] == 3)
            self.assertEqual(engine.counts["accepted"], 2)
            self.assertEqual(engine.counts["rejected"], 2)
            self.assertEqual([p["packet"] for p in engine.history], [1, 3])
        finally:
            stop.set()
            reader.join(timeout=1)
            os.close(master)
            os.close(slave)

    def test_two_usb_streams_handshake_capture_and_attack_results(self):
        import pty
        pairs = [pty.openpty(), pty.openpty()]
        stop = threading.Event()
        engine = Engine(KEY, "secure")
        lab = SerialLab(engine, os.ttyname(pairs[0][1]), os.ttyname(pairs[1][1]), 115200)
        captures = []; commands = []; errors = []

        def emulate(role, fd):
            buffer = b""; nonce = None; counter = 0; sent_at = 0; capture = None
            try:
                while not stop.is_set():
                    readable, _, _ = select.select([fd], [], [], .03)
                    if readable:
                        buffer += os.read(fd, 8192)
                    while b"\n" in buffer:
                        raw, buffer = buffer.split(b"\n", 1)
                        line = raw.decode("ascii", errors="replace").strip()
                        if role == "device" and line.startswith("SESSION "):
                            _, n, mac = line.split()
                            if tag(KEY, "MS1-SESSION|" + n) != mac:
                                raise AssertionError("Host handshake HMAC failed")
                            if n != nonce:
                                nonce, counter = n, 0
                        elif role == "device" and line.startswith("ALARM "):
                            _, n, value, mac = line.split()
                            if tag(KEY, f"MS1-ALARM|{n}|{value}") != mac:
                                raise AssertionError("Host alarm HMAC failed")
                            commands.append(value)
                        elif role == "attacker" and line.startswith("CAPTURE "):
                            capture = json.loads(line[8:]); captures.append(capture)
                        elif role == "attacker" and line.startswith("ATTACK "):
                            name = line[7:]
                            p = copy.deepcopy(capture)
                            if name == "altered": p["heart_rate_bpm"] = 110
                            if name == "spoof": p["device_id"] = "FORGED-DEVICE"
                            os.write(fd, (json.dumps(p) + "\n").encode())
                    if role == "device" and nonce and time.monotonic() - sent_at > .1:
                        counter += 1
                        os.write(fd, (json.dumps(signed_packet(KEY, nonce, counter)) + "\n").encode())
                        sent_at = time.monotonic()
            except Exception as exc:
                errors.append(repr(exc))

        def wait_for(predicate, seconds=5):
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                if predicate(): return
                time.sleep(.02)
            self.fail("Timed out waiting for simulated serial integration state; " + repr(engine.snapshot()))

        workers = [threading.Thread(target=emulate, args=(role, pair[0]), daemon=True)
                   for role, pair in zip(("device", "attacker"), pairs)]
        try:
            for worker in workers: worker.start()
            lab.start(stop)
            wait_for(lambda: len(captures) >= 2 and len(commands) >= 1)
            self.assertGreaterEqual(engine.counts["authenticated"], 2)
            for attack, reason in (("replay", "replay"), ("altered", "bad_mac"), ("spoof", "unknown_device")):
                self.assertTrue(engine.attack(attack)[0])
                wait_for(lambda r=reason: engine.counts[r] >= 1)
            engine.manual_alert()
            wait_for(lambda: "1" in commands)
            self.assertEqual(engine.counts["rejected"], 3)
            self.assertTrue(all(p["authenticated"] for p in engine.history))
            self.assertEqual(errors, [])
        finally:
            stop.set()
            for worker in workers: worker.join(timeout=1)
            time.sleep(.4)
            for pair in pairs:
                for fd in pair:
                    os.close(fd)


if __name__ == "__main__":
    unittest.main(verbosity=2)
