"""Run the real suite and write machine-readable software-only evidence."""
from datetime import datetime, timezone
import importlib.metadata
import io
import json
from pathlib import Path
import platform
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.records.append({"test": test.id(), "status": "passed"})

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.records.append({"test": test.id(), "status": "failed"})

    def addError(self, test, err):
        super().addError(test, err)
        self.records.append({"test": test.id(), "status": "error"})

    def addSkip(self, test, reason):
        super().addSkip(test, reason)
        self.records.append({"test": test.id(), "status": "skipped", "reason": reason})


def main():
    stream = io.StringIO()
    started = time.perf_counter()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_*.py")
    result = unittest.TextTestRunner(stream=stream, verbosity=2, resultclass=RecordingResult).run(suite)
    duration = time.perf_counter() - started
    output = stream.getvalue()
    print(output, end="")
    evidence = ROOT / "evidence"
    evidence.mkdir(exist_ok=True)
    details = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Software unit/API tests and POSIX PTY serial emulation only; no physical boards",
        "command": "python tests/run_evidence.py",
        "equivalent_validation_command": "python -m unittest discover -s tests -v",
        "python": platform.python_version(), "platform": platform.platform(),
        "dependencies": {name: importlib.metadata.version(name) for name in ("Flask", "pyserial")},
        "tests_run": result.testsRun, "passed": sum(x["status"] == "passed" for x in result.records),
        "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
        "successful": result.wasSuccessful(), "duration_seconds": round(duration, 3),
        "tests": result.records,
        "hardware_status": "Arduino sketches uncompiled here; firmware upload, wiring, physical USB, LEDs, OLED, buzzer and physical button require Saif's validation."
    }
    (evidence / "software_tests.json").write_text(json.dumps(details, indent=2) + "\n")
    (evidence / "software_tests.md").write_text(
        "# Software verification evidence\n\n"
        f"Executed {details['generated_utc']} using Python {details['python']}.\n\n"
        f"**{details['passed']}/{result.testsRun} passed; {len(result.failures)} failures, {len(result.errors)} errors, {len(result.skipped)} skipped.**\n\n"
        "Run from the extracted MediSentinel_Research folder:\n\n"
        "```powershell\npython -m unittest discover -s tests -v\n```\n\n"
        "To regenerate JSON and this evidence file: `python tests/run_evidence.py`.\n\n"
        "Coverage: strict canonical HMAC authentication; signed sequence gaps; replay and old-counter rejection; "
        "fresh-session old-message rejection; tampering, unknown identity, schema/type/bounds/nonfinite rejection; "
        "rejected packets excluded from graphs and ML; explicit legacy UNVERIFIED mode with ML disabled; "
        "manual overlay distinct from telemetry; ML unavailability; HTTP local-action token, Origin/Host restrictions, "
        "request-size limits, cache/security headers and actual template rendering.\n\n"
        "The POSIX PTY integration test runs the actual pyserial reader/writer with two emulated serial streams. "
        "It validates authenticated SESSION and ALARM commands, telemetry acceptance, CAPTURE forwarding, "
        "and rejected replay/altered/spoof outputs returned by the emulated second node. "
        "This is simulated serial integration, not ESP32/ESP8266 hardware verification. "
        "On Windows, the PTY-only test is skipped; the other tests still run.\n\n"
        "**Hardware status:** Arduino sketches have not been compiled here. Firmware upload, physical USB, wiring, "
        "LEDs, OLED, buzzer and physical button remain unverified until Saif tests them. "
        "The ML benchmark is documented separately in `metrics.json` and `evaluation.md`; these tests do not establish clinical or real-world attack performance.\n\n"
        "During verification, nonfinite-input audit logging and the serial-writer/engine lock acquisition order "
        "were corrected to prevent a malformed input crash and a possible connection-failure deadlock. "
        "Legacy numeric bounds are checked before conversion, preventing overflow on huge invalid integers.\n\n"
        "## Actual test output\n\n```text\n" + output + "```\n"
    )
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
