# MediSentinel

**Saif | Individual INUNI Hackathon AI-track entry | Student research prototype**

MediSentinel combines an ESP32 simulated medical device, an ESP8266 authorised USB test node, a local Python dashboard, message authentication/replay checks and a trained One-Class SVM anomaly detector. All heart-rate and oxygen values are generated. There are no medical sensors or patient measurements.

## Report

- [Final report (PDF)](docs/MediSentinel_Research_Report.pdf)
- [Editable report (Word)](docs/MediSentinel_Research_Report.docx)
- [Report text](docs/REPORT_TEXT.md)
- [Submission abstract](docs/SUBMISSION_ABSTRACT.txt)

## Run the software demonstration

Use Python 3.12. From this folder, create a virtual environment and install the runtime dependencies:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements_runtime.txt
.\.venv\Scripts\python.exe medisentinel_secure.py --demo --http-port 5004
```

Open http://127.0.0.1:5004/. The SOFTWARE DEMO label identifies this mode. The manual alert checks the warning display; it is separate from attack rejection and machine-learning detection.

## Run the two-board USB lab

See [hardware instructions](HARDWARE.md). Generate a fresh private key with `python setup_lab.py` before compiling the ESP32 sketch. This creates `.local/lab_key.txt` and `firmware/MediSentinel_ESP32/secrets.h`; neither belongs in this repository. Do not give the key to the ESP8266. Use ArduinoJson 7 and the appropriate ESP32/NodeMCU board profiles.

After firmware uploads, close Arduino Serial Monitor and start:

```powershell
.\.venv\Scripts\python.exe medisentinel_secure.py --port COM3 --attacker-port COM8 --http-port 5004
```

COM3 and COM8 were Saif's ports; choose the ports assigned on your laptop. Both boards use 115200 baud. USB supplies power and data. The test node receives a captured message from the laptop, so this is a controlled wired lab, not wireless interception. Keep optional OLED and sound outputs disabled unless separately validated.

## Recorded results and limitations

- Six physical USB trials on 8 November 2026 gave the expected replay, altered-message and unknown-device rejections, two trials per case, after a serial-framing repair.
- Saif confirmed the manual alert changed physical LEDs from green to red and back on 10 November. This verifies the output path, not an ML decision. The final report records this update; earlier evidence files retain their original dated observations.
- The automated software suite recorded 26 passing checks, including emulated serial tests. POSIX-only integration tests are skipped on Windows.
- Held-out ML evaluation used 17,280 generated readings: precision 90.40%, recall 54.79%, false-positive rate 2.91%. Training (9,000 normal readings), calibration (3,600 normal readings) and test episodes were separate.
- The model missed most frozen values and small changes. These synthetic packet-level results do not establish performance on real medical devices, patients or unseen attacks.

The laptop checks HMAC-SHA256 tags, identity, session and increasing packet numbers before scoring accepted readings. HMAC does not encrypt data. The model is a trained StandardScaler/RBF One-Class SVM; it is separate from fixed security rules. Portable JSON inference runs locally without a paid AI API. Load only trusted local model files, especially the included joblib format.

## Reproduce software checks and evaluation

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe train_evaluate.py
```

The evaluation command regenerates model/evidence files. See [evaluation notes](evidence/evaluation.md), [recorded metrics](evidence/metrics.json), [physical USB record](evidence/laptop_hardware_checks_2026-11-08.json) and [software checks](evidence/software_tests.json). The reported training environment is recorded in the metrics. Existing runtime inference needs only the smaller runtime requirements.

## Contribution and AI assistance

ChatGPT/Codex helped with code, tests, troubleshooting and writing. Saif connected the boards, uploaded firmware, wired and tested the LEDs, ran the laptop demonstrations and recorded the presentation. This is a student research prototype, not a medical product. No real deployment or clinical validation is claimed.

Private keys, local logs, virtual environments and unrelated original PC-monitor files are excluded from this publishing copy.
