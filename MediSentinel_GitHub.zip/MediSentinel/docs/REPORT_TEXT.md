# MediSentinel

Saif | INUNI Hackathon 2026 | AI track | Individual entry | 10 November 2026

### Abstract

MediSentinel is a student research prototype for checking data sent by a small device. I built it to bring together my cybersecurity learning and practical work with Arduino boards. The project uses generated heart-rate and oxygen values. There are no medical sensors or patient measurements.

An ESP32 sends protected messages to a dashboard on my laptop. A second board, the ESP8266, returns controlled test messages through another USB connection. The laptop checks the device identity, authentication tag, session and packet number. Replayed, altered and unknown-device messages gave the expected rejections in six physical USB trials. A manual alert also changed the LEDs from green to red and back to green.

A One-Class SVM model checks accepted readings for unusual patterns. Training, choosing the alert level and testing use separate generated data. In a test of 17,280 readings, precision was 90.40%, recall was 54.79%, and the false-positive rate was 2.91%. The model found some unusual patterns but missed many small changes and frozen values.

The prototype runs locally without paid AI services or hosting. AI tools helped with development and writing. The results demonstrate a working student lab, with further testing needed before any conclusions about medical use.

## 1 Purpose

I wanted to use what I am learning in cybersecurity to build something I could test myself. My question was simple: can I check whether a message from a small device can be trusted, and then use machine learning to notice unusual values?

Healthcare gave this idea a useful context. The U.S. Department of Justice records a ransomware attack on Scripps Health on 1 May 2021 [1]. This is one example of why healthcare cybersecurity matters. My project focuses on a much smaller problem, which is checking device messages. It does not detect ransomware or claim that it could have prevented the Scripps Health attack.

Medical IoT refers to medical devices that exchange data. I did not have medical sensors, so I used an ESP32 to represent a device sending heart-rate and oxygen readings. Every reading is marked as simulated. This allowed me to work with a controlled example and avoid using patient information. I aimed to make the demonstration affordable and repeatable with the equipment I already had.

## 2 Procedure

I uploaded a different Arduino sketch to each board and connected both to my laptop by USB. The ESP32 uses COM3 and the ESP8266 uses COM8, both at 115200 baud. A Python program runs a Flask dashboard locally on port 5004. The browser displays the accepted readings, graphs, packet counts and alerts.

The ESP32 generates the readings and adds a security tag to each message. The laptop checks these messages and runs the machine-learning model. The ESP8266 is my authorised test device. The laptop gives it a copy of an accepted message, which it can return as an old message or a changed test copy. This is a controlled USB experiment. I did not intercept wireless traffic or test devices belonging to other people.

### Message checks

The ESP32 and laptop share a secret key. The ESP8266 does not receive this key. I use HMAC-SHA256 to calculate a tag from the key and the message contents. The laptop calculates the tag again and checks whether it matches [2,3]. If a protected value changes without a matching tag, the check fails. This protects message integrity, but it does not encrypt the readings. Their contents are still visible.

A correct tag alone cannot stop someone from sending an old valid message again. To address this, the program also checks the session and packet number. A session is a fresh random label for the current connection. Packet numbers must increase within that session. Repeated or older numbers are rejected, as are messages from an earlier session.

The host sends an authenticated session command. Each data packet contains the device ID, session, packet number, heart rate, SpO2, simulated=true and its tag. SpO2 is the oxygen-saturation value being simulated. The program also checks that the fields have the right format and that the device ID is recognised. It records the reason for a rejection. Rejected packets do not update the accepted graphs or the model's previous-reading state.

I kept three kinds of alert separate. A manual alert checks the warning display and outputs. A security alert reports a failed message check. An ML alert means that accepted values look unusual compared with the model's training examples. These alerts do not all prove the same thing.

For the physical output, I connected the red LED to GPIO25 and the green LED to GPIO26. GPIO means the board's general-purpose input/output pins [8]. Each LED has two resistors in series and returns to GND. The board uses USB power, and the breadboard needs no soldering. Authenticated commands from the laptop control the alert outputs. The tested build uses the LEDs. The OLED, physical button and sound output are not included in the verified results.

### Machine learning

The model is a One-Class Support Vector Machine, usually called a One-Class SVM. It learns from normal examples and gives new data a score for how unusual it looks [4]. This trained calculation is separate from the fixed security checks.

I used three groups of generated data. Training teaches the model the normal pattern. Calibration is the stage where the alert level is chosen. The held-out test is kept separate until performance is measured.

| Stage | Readings | Episodes |
|---|---:|---:|
| Training with normal data | 9,000 | 50 |
| Calibration with separate normal data | 3,600 | 20 |
| Held-out test | 17,280 | 96 |

Each episode contains 180 readings, and a whole episode stays in one group. The generation seeds are 78201, 78202 and 78203, allowing the experiment to be repeated. The test includes normal data and six types of unusual behaviour. I did not use a patient dataset or PhysioNet data.

The four model inputs are heart rate, SpO2, and the absolute change in each since the previous accepted reading. StandardScaler puts the inputs on comparable scales [5]. The SVM settings are an RBF kernel, nu=0.02 and gamma=scale.

I set the alert level at the 99th percentile of normal calibration scores, approximately -18.598909. Higher scores mean more unusual data, not a higher probability of an attack. Test labels were not used to choose this level. Earlier model experiments informed development, so the evaluation is still an internal project test.

The trained model is also saved in JSON. The laptop can then perform the same learned calculation using Python's standard library, without calling an online AI model.

## 3 Results

### Hardware and software tests

Both sketches uploaded successfully, and the dashboard received authenticated simulated readings. After a repair to the serial-message reader, I ran each of the following tests twice on 8 November 2026.

| USB test | Recorded decision | Result |
|---|---|---|
| Send an accepted message again | replay | Expected rejection in 2 of 2 trials |
| Change a reading and keep its old tag | bad_mac | Expected rejection in 2 of 2 trials |
| Use an unknown device identity | unknown_device | Expected rejection in 2 of 2 trials |

These six trials show that the intended checks worked in this lab. They do not measure protection against all possible attacks. A saved dashboard snapshot showed 145 authenticated samples and six rejections. At that point, the active model had flagged one normal simulated sample. This short observation was not used to calculate a hardware false-alarm rate.

On 10 November, I connected and tested the LEDs. Green was on while the device was connected with no active alert. When I triggered the manual alert, red came on and green went off. Green returned after the alert ended. This confirmed the connection between the dashboard warning and the physical LEDs. A manual trigger does not by itself prove that the model detected anything.

The serial-message repair was an important part of the testing. Some USB messages arrived in pieces, and the program tried to read them before the complete JSON line had arrived. Two early altered-message trials produced a format error rather than the expected authentication failure. The revised reader waits for the line ending, keeps partial data and limits oversized messages. I excluded those two early failures from the six successful trials reported above.

The recorded automated suite passed 26 of 26 checks. These cover message validation, protection of accepted data, dashboard actions and emulated serial connections, including fragmented input. They are software tests, separate from the physical-board trials. Some serial tests require POSIX features and are skipped on Windows.

The JSON model was also compared with the original trained pipeline on 17,380 inputs. No anomaly decisions differed. The largest raw-score difference was about 1.07 x 10^-14, supporting its use for local scoring.

### Machine-learning results

The held-out test contained 11,520 normal readings and 5,760 readings labelled unusual by the generator. The following results count individual readings, rather than patients or physical attacks.

| Outcome or measure | One-Class SVM | Simple example limits |
|---|---:|---:|
| Unusual readings correctly flagged | 3,156 | 1,920 |
| Unusual readings missed | 2,604 | 3,840 |
| Normal readings correctly left unflagged | 11,185 | 11,520 |
| Normal readings wrongly flagged | 335 | 0 |
| Precision | 90.40% | 100.00% |
| Recall | 54.79% | 33.33% |
| False-positive rate | 2.91% | 0.00% |

For comparison, the simple rules flag heart rate below 50 or above 120, or oxygen below 92. I chose these as example limits for the demonstration. They are not validated medical thresholds. The SVM found more unusual readings overall, but it also produced false alarms. Its F1 score, which combines precision and recall, was 0.6823 [6].

Performance varied considerably between the generated patterns. Each unusual case contained 960 labelled unusual readings.

| Generated pattern | Readings found out of 960 | Recall |
|---|---:|---:|
| Sudden change inside the example limits | 960 | 100.00% |
| Low oxygen value | 960 | 100.00% |
| High heart rate with low oxygen | 960 | 100.00% |
| Gradual drift | 255 | 26.56% |
| Frozen values that look typical | 3 | 0.31% |
| Small change inside the example limits | 18 | 1.88% |

The model missed most frozen values and small changes. Normal-only episodes produced 19 false alarms in 2,160 readings. A harmless baseline shift of +3 BPM produced 195 in 2,160, or 9.03%. This shows that a change in normal behaviour can also confuse the model.

Authentication can reject an unauthorised change even when its value looks normal. The model looks for unusual values in accepted messages, but cannot confirm an attack or a medical problem.

## 4 Conclusion

I built a working local prototype with simulated device data, message checks and a trained anomaly detector. Both USB boards worked in the recorded tests, and the LEDs responded to the manual alert. The security trials gave the expected rejections for the three tested cases. The model detected some useful patterns, although its missed cases show that it still needs improvement.

The project helped me understand why the reason behind an alert matters. During the partial-message problem, a rejection did not mean that the intended authentication check had worked. I had to correct the input handling and repeat the test. I also learned why model training, choosing an alert level and final testing should be kept separate.

There are clear limits to these results. Training and testing use the same basic generator. Separate episodes and seeds reduce overlap, but they do not demonstrate performance on real sensors or patients. Nearby readings are related, so thousands of packets should not be treated as thousands of independent clinical trials.

The security design assumes that the laptop, firmware and secret key can be trusted. A stolen key or compromised laptop is outside the tested scope. The data is not encrypted, and a delayed valid message with a new packet number can pass because strict packet expiry has not been added. The Flask dashboard remains a local development service [7].

My next steps would be longer stability runs, deliberate reconnect tests and model inputs that consider a longer history of readings. Any revised model would need fresh evaluation data. Further independent testing would be necessary before considering real medical use.

I used ChatGPT/Codex for help with code, testing, troubleshooting and writing. I made the USB connections, uploaded the firmware, wired and tested the LEDs, ran the laptop demonstrations and recorded the video. I worked through the system so I could explain it. The detector running in the project is the local SVM, not a conversational AI service.

## 5 Tests and numbers in plain English

The percentages can seem confusing because they start with different groups of readings. Precision starts with the model's warnings. Recall starts with all the unusual readings. The false-positive rate starts with normal readings [6].

**Precision was 90.40%.** The model raised 3,491 warnings. Of these, 3,156 matched readings labelled unusual and 335 were false alarms. Dividing 3,156 by 3,491 gives about 90.40%. In simple terms, about 90 out of every 100 warnings were correct in this test.

**Recall was 54.79%.** There were 5,760 unusual readings altogether. The model found 3,156 and missed 2,604. Dividing 3,156 by 5,760 gives about 54.79%. This means it caught about 55 out of every 100 unusual readings and missed about 45.

**The false-positive rate was 2.91%.** Out of 11,520 normal readings, 335 were wrongly flagged. Dividing 335 by 11,520 gives about 2.91%, or roughly 3 false alarms for every 100 normal readings.

Most warnings can be correct even while many unusual readings are missed. That is why the precision figure should be read together with recall. All three figures describe the generated test data and are not promises about future medical data.

The demonstration provides other kinds of evidence. An increasing authenticated count shows that the laptop is accepting messages from the ESP32. The three USB cases show the corresponding security checks. The green-to-red-to-green sequence shows the manual warning and LED response. In the separate SOFTWARE DEMO mode, a deliberately unusual example shows that the trained model can flag that generated input.

The ML percentages come from the complete held-out test, not from counting a few warnings in the video. The six USB trials, 26 automated checks and physical LED observation should each be understood on their own terms.

## References

Web references were checked on 10 November 2026. Current documentation may describe newer versions than the recorded experiment.

[1] U.S. Department of Justice (2023). Multiple Foreign Nationals Charged in Connection with Conti Ransomware and Trickbot Malware Conspiracies. Includes the Scripps Health attack of 1 May 2021. https://www.justice.gov/usao-mdtn/pr/multiple-foreign-nationals-charged-connection-conti-ransomware-and-trickbot-malware

[2] Krawczyk, Bellare and Canetti (1997). RFC 2104: HMAC: Keyed-Hashing for Message Authentication. https://www.rfc-editor.org/rfc/rfc2104

[3] Python Software Foundation. hmac: Keyed-Hashing for Message Authentication. https://docs.python.org/3/library/hmac.html

[4] scikit-learn. OneClassSVM reference. https://scikit-learn.org/stable/modules/generated/sklearn.svm.OneClassSVM.html

[5] scikit-learn. StandardScaler reference. https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.StandardScaler.html

[6] scikit-learn. Metrics and scoring: quantifying the quality of predictions. https://scikit-learn.org/stable/modules/model_evaluation.html

[7] Pallets Projects. Flask: Deploying to Production. https://flask.palletsprojects.com/en/stable/deploying/

[8] Espressif Systems. Arduino-ESP32 GPIO reference. https://docs.espressif.com/projects/arduino-esp32/en/latest/api/gpio.html

The project evidence folder contains metrics.json and evaluation.md for the model settings and results, synthetic_benchmark.csv for the generated data, laptop_hardware_checks_2026-11-08.json for the physical USB trials, software_tests.json for the automated checks, and portable_model_verification.json for the model comparison. The 10 November LED result is based on my direct observation during the final build and demonstration.

The recorded ML environment used Python 3.12.14, NumPy 2.3.5, scikit-learn 1.8.0 and joblib 1.5.3. The source includes the board sketches, security checks, data generation and evaluation code. All vital values are simulated.
