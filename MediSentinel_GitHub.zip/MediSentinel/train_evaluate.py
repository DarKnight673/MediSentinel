"""Rebuild the local OneClassSVM and measure a held-out SYNTHETIC benchmark.

Train, calibration, and test episodes use separate fixed random seeds. Test labels
never select features, model settings, or threshold. All scenario definitions and
hyperparameters are fixed in source; these are simulated research measurements.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import platform
from datetime import datetime, timezone

import joblib
import numpy as np
import sklearn
from sklearn.svm import OneClassSVM
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support, roc_auc_score

from ml_detector import FEATURE_NAMES, feature_vector

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
MODELS = ROOT / "models"
SEEDS = {"train": 78201, "calibration": 78202, "test": 78203}
SCENARIOS = ["normal", "benign_baseline_shift", "abrupt_in_range", "low_spo2",
             "high_hr_low_spo2", "gradual_drift", "frozen_typical", "small_in_range_alteration"]
EPISODE_LENGTH = 180
N_EPISODES = {"train": 50, "calibration": 20, "test": 12}
CALIBRATION_QUANTILE = 0.99


def normal_episode(rng):
    # Independent phases prevent memorizing the absolute sample number.
    phase_hr, phase_spo2 = rng.uniform(0, 2 * math.pi, 2)
    rows = []
    for n in range(EPISODE_LENGTH):
        rows.append({"heart_rate_bpm": round(77 + 7 * math.sin(n / 7 + phase_hr) + rng.uniform(-2, 2)),
                     "spo2_percent": round(97 + math.sin(n / 11 + phase_spo2) + rng.uniform(-0.5, 0.5))})
    return rows


def dataset(split):
    rng = np.random.default_rng(SEEDS[split])
    scenarios = SCENARIOS if split == "test" else ["normal"]
    out = []
    for scenario in scenarios:
        for episode in range(N_EPISODES[split]):
            data = normal_episode(rng)
            previous = None
            for n, original in enumerate(data):
                point = dict(original)
                label = 0
                # Attack-like values are injected only in each test episode's
                # middle 80 packets; prefix/suffix remain labelled normal.
                active = 50 <= n < 130
                if scenario == "benign_baseline_shift":
                    point["heart_rate_bpm"] += 3
                elif active and scenario != "normal":
                    label = 1
                    if scenario == "abrupt_in_range":
                        point.update(heart_rate_bpm=110 + int(rng.integers(-2, 3)), spo2_percent=94)
                    elif scenario == "low_spo2":
                        point.update(spo2_percent=88 + int(rng.integers(-1, 2)))
                    elif scenario == "high_hr_low_spo2":
                        point.update(heart_rate_bpm=140 + int(rng.integers(-3, 4)), spo2_percent=89)
                    elif scenario == "gradual_drift":
                        # A mild baseline alteration with many overlapping samples.
                        point["heart_rate_bpm"] += round((n - 50) / 79 * 12)
                    elif scenario == "frozen_typical":
                        point.update(heart_rate_bpm=77, spo2_percent=97)
                    elif scenario == "small_in_range_alteration":
                        point["heart_rate_bpm"] += 1
                features = feature_vector(point["heart_rate_bpm"], point["spo2_percent"], previous)
                out.append({"split": split, "scenario": scenario,
                            "episode_id": f"{split}-{scenario}-{episode:03d}",
                            "sample_index": n, **point, "label": label,
                            **dict(zip(FEATURE_NAMES[2:], features[2:]))})
                previous = point
    return out


def matrix_metrics(labels, predicted):
    tn, fp, fn, tp = [int(x) for x in confusion_matrix(labels, predicted, labels=[0, 1]).ravel()]
    precision, recall, f1, _ = precision_recall_fscore_support(labels, predicted, average="binary", zero_division=0)
    return {"samples": len(labels), "true_negative": tn, "false_positive": fp,
            "false_negative": fn, "true_positive": tp, "precision": float(precision),
            "recall": float(recall), "f1": float(f1),
            "false_positive_rate": fp / (fp + tn) if fp + tn else None,
            "specificity": tn / (fp + tn) if fp + tn else None,
            "accuracy": (tp + tn) / len(labels)}


def main():
    EVIDENCE.mkdir(exist_ok=True)
    MODELS.mkdir(exist_ok=True)
    all_rows = {split: dataset(split) for split in SEEDS}
    features = lambda rows: np.array([[r[name] for name in FEATURE_NAMES] for r in rows], dtype=float)
    model = make_pipeline(StandardScaler(), OneClassSVM(kernel="rbf", gamma="scale", nu=0.02))
    model.fit(features(all_rows["train"]))
    calibration_scores = -model.score_samples(features(all_rows["calibration"]))
    threshold = float(np.quantile(calibration_scores, CALIBRATION_QUANTILE, method="higher"))
    test_rows = all_rows["test"]
    scores = -model.score_samples(features(test_rows))
    predicted = scores > threshold
    labels = np.array([row["label"] for row in test_rows])
    rules = np.array([row["heart_rate_bpm"] < 50 or row["heart_rate_bpm"] > 120 or row["spo2_percent"] < 92 for row in test_rows])
    per_scenario = {}
    for scenario in SCENARIOS:
        selected = np.array([r["scenario"] == scenario for r in test_rows])
        per_scenario[scenario] = {
            "ml": matrix_metrics(labels[selected], predicted[selected]),
            "static_demo_rule": matrix_metrics(labels[selected], rules[selected])}
    metrics = {"benchmark": "Synthetic telemetry only; no clinical or real deployment validation",
               "generated_at_utc": datetime.now(timezone.utc).isoformat(),
               "seeds": SEEDS, "episode_length": EPISODE_LENGTH,
               "episodes_per_scenario": N_EPISODES, "feature_names": FEATURE_NAMES,
               "train_samples": len(all_rows["train"]), "calibration_samples": len(all_rows["calibration"]),
               "test_samples": len(test_rows), "threshold": threshold,
               "calibration_quantile": CALIBRATION_QUANTILE,
               "calibration_false_positive_rate": float(np.mean(calibration_scores > threshold)),
               "ml": matrix_metrics(labels, predicted), "static_demo_rule": matrix_metrics(labels, rules),
               "roc_auc": float(roc_auc_score(labels, scores)), "per_scenario": per_scenario,
               "runtime": {"python": platform.python_version(), "numpy": np.__version__, "sklearn": sklearn.__version__, "joblib": joblib.__version__}}
    bundle = {"model": model, "threshold": threshold, "feature_names": FEATURE_NAMES,
              "algorithm": "OneClassSVM", "sklearn_version": sklearn.__version__,
              "train_samples": metrics["train_samples"], "calibration_samples": metrics["calibration_samples"],
              "validation_scope": metrics["benchmark"], "threshold_method": "99th percentile of separate normal calibration episodes"}
    joblib.dump(bundle, MODELS / "telemetry_novelty.joblib", compress=3)
    from export_portable_model import export_bundle
    export_bundle(bundle, MODELS / "telemetry_novelty.json")
    (EVIDENCE / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    csv_path = EVIDENCE / "synthetic_benchmark.csv"
    fieldnames = list(all_rows["train"][0]) + ["ml_score", "ml_prediction", "static_demo_rule_prediction"]
    with csv_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for split in SEEDS:
            for index, row in enumerate(all_rows[split]):
                row = dict(row)
                if split == "test":
                    row.update(ml_score=float(scores[index]), ml_prediction=int(predicted[index]), static_demo_rule_prediction=int(rules[index]))
                writer.writerow(row)
    (EVIDENCE / "benchmark_sha256.txt").write_text(hashlib.sha256(csv_path.read_bytes()).hexdigest() + "  synthetic_benchmark.csv\n")
    build_summary(metrics)
    plot_results(metrics, labels, scores, threshold)
    print(json.dumps({"ml": metrics["ml"], "rules": metrics["static_demo_rule"], "threshold": threshold}, indent=2))


def build_summary(m):
    ml = m["ml"]
    lines = ["# Reproducible synthetic ML evaluation", "",
             "These are actual software-run measurements on generated telemetry, not patient data or observed hardware attacks.", "",
             f"Training: {m['train_samples']:,} normal packets (50 independent episodes). Calibration: {m['calibration_samples']:,} normal packets (20 episodes). Test: {m['test_samples']:,} packets, 12 entirely separate episodes for each of eight scenarios. Each episode has 180 samples; anomalous test episodes alter samples 50–129 only.", "",
             "Whole episodes are assigned to exactly one split. Fixed split seeds are 78201/78202/78203. No random row split is used. Training and calibration are normal-only. Test labels are used only for reporting. Scenario design is a synthetic specification, so this is not proof of generalization to unseen real attacks.", "",
             "Model: scikit-learn StandardScaler followed by RBF OneClassSVM, nu=0.02, gamma=scale. Four shared features: HR, SpO2, absolute HR delta, absolute SpO2 delta. The first sample of each independent episode/session uses zero deltas. Delta features use consecutive accepted packets in live operation; timing is not a feature.", "",
             f"The score is negative score_samples (higher means more unusual). Alarm if score > {m['threshold']:.9f}; threshold fixed from the separate normal calibration 99th percentile (higher quantile method). Calibration false-positive rate: {m['calibration_false_positive_rate']:.2%}.", "",
             f"Held-out ML: precision {ml['precision']:.2%}, recall {ml['recall']:.2%}, F1 {ml['f1']:.4f}, false-positive rate {ml['false_positive_rate']:.2%}. Confusion counts TN={ml['true_negative']}, FP={ml['false_positive']}, FN={ml['false_negative']}, TP={ml['true_positive']}. ROC AUC={m['roc_auc']:.4f}.", "",
             "All rates are packet-level, not patient-level, episode-level or hardware-attack success rates. Adjacent packets are correlated; no independence-based confidence interval is claimed. Alert latching/cooldown can change visible event counts, so dashboard events are not confusion-matrix counts.", "",
             "| Held-out scenario | Anomalous packets | ML recall | ML false positives / normal | Static-rule recall |", "|---|---:|---:|---:|---:|"]
    for scenario, result in m["per_scenario"].items():
        a, b = result["ml"], result["static_demo_rule"]
        n_positive = a["true_positive"] + a["false_negative"]
        recall = f"{a['recall']:.1%}" if n_positive else "N/A"
        rule_recall = f"{b['recall']:.1%}" if n_positive else "N/A"
        lines.append(f"| {scenario.replace('_', ' ')} | {n_positive} | {recall} | {a['false_positive']} / {a['false_positive']+a['true_negative']} | {rule_recall} |")
    rule = m["static_demo_rule"]
    lines += ["", f"Static demonstration rule baseline (HR <50 or >120, SpO2 <92): precision {rule['precision']:.2%}, recall {rule['recall']:.2%}, F1 {rule['f1']:.4f}, false-positive rate {rule['false_positive_rate']:.2%}. These illustrative limits are not clinical guidance.", "",
              "Frozen typical telemetry and +1 BPM alterations deliberately overlap normal values. This four-feature model can miss them; cryptographic authentication is what rejects unauthorized modifications. Benign baseline shift (+3 BPM) is labelled normal and tests false alarms under modest distribution shift. Normal prefixes/suffixes are also included in confusion counts, including transition-related false alarms.", "",
              "Security rejection and ML are measured separately: HMAC/session/counter checks reject replay or tampered messages before live scoring. ML detects unusual *accepted, authenticated* telemetry, including anomalies generated by the legitimate simulated device; an ML alert alone does not prove a cyberattack.", "",
              "Reproduce with `python train_evaluate.py`. Use only trusted local model artifacts: joblib uses pickle and loading an attacker-supplied file can execute code. Retrain locally if the scikit-learn version differs. The first IsolationForest pilot had poor anomaly recall (6.46%); its metrics are retained separately. A LOF candidate was rejected for numerical instability using normal-only calibration. The revised OneClassSVM design and new split seeds were fixed before this reported test was generated; this is one held-out synthetic evaluation of the revision, not a preregistered external study. No threshold adjustment used the reported test labels.", "",
              "Software versions: " + json.dumps(m["runtime"]) ]
    (EVIDENCE / "evaluation.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def plot_results(m, labels, scores, threshold):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8), constrained_layout=True)
    matrix = np.array([[m["ml"]["true_negative"], m["ml"]["false_positive"]], [m["ml"]["false_negative"], m["ml"]["true_positive"]]])
    axes[0].imshow(matrix, cmap="Blues")
    for (i, j), value in np.ndenumerate(matrix):
        axes[0].text(j, i, f"{value:,}", ha="center", va="center", color="white" if value > matrix.max() / 2 else "#14213d", fontsize=14)
    axes[0].set(xticks=[0, 1], yticks=[0, 1], xticklabels=["Normal", "Anomaly"], yticklabels=["Normal", "Anomaly"], xlabel="Predicted", ylabel="Label", title="Held-out packet confusion matrix")
    axes[1].hist(scores[labels == 0], bins=45, alpha=.7, label="Normal", density=True, color="#167d9a")
    axes[1].hist(scores[labels == 1], bins=45, alpha=.6, label="Injected anomaly", density=True, color="#d14c5d")
    axes[1].axvline(threshold, color="#111", linestyle="--", label="Calibration threshold")
    axes[1].set(xlabel="Anomaly score (higher = more unusual)", ylabel="Density", title="Synthetic test score distributions")
    axes[1].legend(fontsize=8)
    fig.suptitle("MediSentinel — synthetic telemetry only", fontsize=13)
    fig.savefig(EVIDENCE / "ml_evaluation.png", dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()
