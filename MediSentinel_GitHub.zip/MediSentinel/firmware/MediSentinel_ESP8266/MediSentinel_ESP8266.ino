/* MediSentinel authorized local test node — USB serial, no radio traffic.
 * Target: NodeMCU 1.0 (ESP-12E Module) USB development board.
 * Dependency: ArduinoJson 7. This node NEVER receives the signing key.
 * CAPTURE <JSON> stores an observed valid device packet.
 * ATTACK replay|altered|spoof sends a controlled test packet to host USB serial.
 */
#include <Arduino.h>
#include <ArduinoJson.h>

constexpr size_t MAX_LINE = 2048;
String inputLine;
String captured;
bool droppingLine = false;

void event(const char *name) {
  JsonDocument doc;
  doc["status"] = name;
  doc["simulated"] = true;
  serializeJson(doc, Serial);
  Serial.println();
}

void command(const String &line) {
  if (line.startsWith("CAPTURE ")) {
    String candidate = line.substring(8);
    JsonDocument doc;
    if (deserializeJson(doc, candidate) || !doc.is<JsonObject>() ||
        !doc["mac"].is<const char *>() || !doc["packet"].is<uint32_t>()) {
      event("capture_invalid"); return;
    }
    bool firstCapture = captured.length() == 0;
    captured = candidate;
    if (firstCapture) event("capture_ready");
    return;
  }
  if (!line.startsWith("ATTACK ")) return;
  if (!captured.length()) { event("capture_required"); return; }
  String mode = line.substring(7);
  if (mode == "replay") { Serial.println(captured); return; }
  JsonDocument doc;
  if (deserializeJson(doc, captured)) { event("capture_invalid"); return; }
  if (mode == "altered") {
    // Keep captured signature: authentication should reject the edited payload.
    int before = doc["heart_rate_bpm"].as<int>();
    doc["heart_rate_bpm"] = before == 149 ? 150 : 149;
  } else if (mode == "spoof") {
    doc["device_id"] = "FORGED-DEVICE-99";
  } else {
    event("attack_unknown"); return;
  }
  serializeJson(doc, Serial);
  Serial.println();
}

void setup() {
  Serial.begin(115200);
  inputLine.reserve(MAX_LINE);
  captured.reserve(MAX_LINE);
  event("authorized_test_node_ready");
}

void loop() {
  size_t consumed = 0;
  while (Serial.available() && consumed++ < 128) {
    char c = static_cast<char>(Serial.read());
    if (c == '\r') continue;
    if (c == '\n') {
      if (!droppingLine && inputLine.length()) command(inputLine);
      inputLine = "";
      droppingLine = false;
    } else if (!droppingLine) {
      if (inputLine.length() >= MAX_LINE) {
        inputLine = "";
        droppingLine = true;
        event("line_too_long");
      } else inputLine += c;
    }
  }
  yield();
}
