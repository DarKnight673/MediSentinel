#pragma once
// Run the project key-generation command to create secrets.h beside this file.
// LAB_KEY is 64 lowercase hex characters USED AS ASCII BYTES (not hex-decoded).
// Use a fresh random key for your own local lab; do not publish secrets.h.
static const char *LAB_KEY = "REPLACE_USING_THE_PROJECT_KEY_GENERATOR";
