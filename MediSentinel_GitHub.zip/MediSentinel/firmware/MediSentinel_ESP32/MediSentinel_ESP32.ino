/* MediSentinel — simulated medical-IoT research device, USB serial only.
 * Target: classic ESP32-WROOM development board, Arduino-ESP32 core.
 * No clinical measurements. No Wi-Fi, Bluetooth, or remote attack traffic.
 * Libraries: ArduinoJson 7; optional Adafruit SSD1306 + Adafruit GFX.
 * Copy/generated secrets.h belongs beside this sketch. Never publish real keys.
 */
#include <Arduino.h>
#include <ArduinoJson.h>
#include <math.h>
#include <esp_system.h>
#include <mbedtls/md.h>
#include "secrets.h"

#define ENABLE_OLED 0
#define ENABLE_BUZZER 0
// Enable buzzer ONLY after the documented electrical compatibility check.
constexpr uint8_t RED_PIN = 25;
constexpr uint8_t GREEN_PIN = 26;
constexpr uint8_t BUTTON_PIN = 27;
constexpr uint8_t BUZZER_PIN = 32;
constexpr char DEVICE_ID[] = "MEDI-ESP32-01";
constexpr size_t MAX_LINE = 1024;
#if ENABLE_OLED
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
Adafruit_SSD1306 display(128, 64, &Wire, -1);
bool oledReady = false;
#endif

String session;
String inputLine;
bool droppingLine = false;
bool hostAlarm = false;
bool hostSeen = false;
uint32_t lastHostAt = 0;
uint32_t sequence = 0;
uint32_t lastSampleAt = 0;
uint32_t localAlarmUntil = 0;
bool localAlarmEnabled = false;
int lastBpm = 0;
int lastSpo2 = 0;
int rawButton = HIGH;
int stableButton = HIGH;
uint32_t lastButtonChangeAt = 0;

bool isLowerHex(const String &s, size_t length) {
  if (s.length() != length) return false;
  for (size_t i = 0; i < length; ++i) {
    char c = s[i];
    if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
  }
  return true;
}

String hmacHex(const String &message) {
  unsigned char digest[32];
  const mbedtls_md_info_t *info = mbedtls_md_info_from_type(MBEDTLS_MD_SHA256);
  if (!info || mbedtls_md_hmac(info,
      reinterpret_cast<const unsigned char *>(LAB_KEY), strlen(LAB_KEY),
      reinterpret_cast<const unsigned char *>(message.c_str()), message.length(), digest) != 0) {
    return "";
  }
  char hex[65];
  for (size_t i = 0; i < 32; ++i) snprintf(hex + 2 * i, 3, "%02x", digest[i]);
  hex[64] = '\0';
  return String(hex);
}

bool validTag(const String &message, const String &tag) {
  if (!isLowerHex(tag, 64)) return false;
  String expected = hmacHex(message);
  if (expected.length() != 64) return false;
  // Fixed-length comparison avoids the normal String equality early exit.
  unsigned char difference = 0;
  for (size_t i = 0; i < 64; ++i) difference |= expected[i] ^ tag[i];
  return difference == 0;
}

void emitEvent(const char *event) {
  JsonDocument doc;
  if (strcmp(event, "manual_button") == 0) doc["event"] = event;
  else doc["status"] = event;
  doc["simulated"] = true;
  serializeJson(doc, Serial);
  Serial.println();
}

void command(const String &line) {
  if (line.startsWith("SESSION ")) {
    String body = line.substring(8);
    int divider = body.indexOf(' ');
    if (divider != 32) return;
    String proposed = body.substring(0, divider);
    String tag = body.substring(divider + 1);
    if (!isLowerHex(proposed, 32) || !validTag("MS1-SESSION|" + proposed, tag)) return;
    bool changed = session != proposed;
    if (changed) {
      session = proposed;
      sequence = 0;
      lastSampleAt = millis() - 1000;
      hostAlarm = false;
    }
    hostSeen = true;
    lastHostAt = millis();
    if (changed) emitEvent("session_ready");
    return;
  }
  if (line.startsWith("ALARM ")) {
    String body = line.substring(6);
    int a = body.indexOf(' ');
    int b = body.indexOf(' ', a + 1);
    if (a != 32 || b != 34) return;
    String proposed = body.substring(0, a);
    String value = body.substring(a + 1, b);
    String tag = body.substring(b + 1);
    if (session.length() != 32 || proposed != session || (value != "0" && value != "1")) return;
    if (!validTag("MS1-ALARM|" + proposed + "|" + value, tag)) return;
    hostAlarm = value == "1";
    hostSeen = true;
    lastHostAt = millis();
  }
}

void pollSerial() {
  // Each pass consumes a bounded amount, allowing LED/button updates under load.
  size_t consumed = 0;
  while (Serial.available() && consumed++ < 128) {
    char c = static_cast<char>(Serial.read());
    if (c == '\r') continue;
    if (c == '\n') {
      if (!droppingLine && inputLine.length()) command(inputLine);
      inputLine = "";
      droppingLine = false;
    } else if (!droppingLine) {
      if (inputLine.length() >= MAX_LINE) {
        inputLine = "";
        droppingLine = true;
      } else inputLine += c;
    }
  }
}

bool localAlarm(uint32_t now) {
  if (localAlarmEnabled && static_cast<int32_t>(now - localAlarmUntil) >= 0) {
    localAlarmEnabled = false;
  }
  return localAlarmEnabled;
}

void pollButton(uint32_t now) {
  int reading = digitalRead(BUTTON_PIN);
  if (reading != rawButton) {
    rawButton = reading;
    lastButtonChangeAt = now;
  }
  if (now - lastButtonChangeAt >= 35 && stableButton != rawButton) {
    stableButton = rawButton;
    if (stableButton == LOW) {
      localAlarmEnabled = !localAlarm(now);
      localAlarmUntil = now + 15000;
      emitEvent(localAlarmEnabled ? "manual_button" : "manual_button_clear");
    }
  }
}

void sample(uint32_t now) {
  if (session.length() != 32 || now - lastSampleAt < 1000) return;
  lastSampleAt = now;
  if (sequence == UINT32_MAX) { session = ""; emitEvent("sequence_exhausted_restart_host"); return; }
  ++sequence;
  bool manual = localAlarm(now);
  float n = static_cast<float>(sequence);
  lastBpm = manual ? 130 + random(-2, 3) :
      static_cast<int>(lroundf(77.0f + 7.0f * sinf(n / 7.0f) + random(-200, 201) / 100.0f));
  lastSpo2 = manual ? 89 :
      static_cast<int>(lroundf(97.0f + sinf(n / 11.0f) + random(-50, 51) / 100.0f));
  String canonical = String("MS1|") + DEVICE_ID + "|" + session + "|" + String(sequence) +
      "|" + String(lastBpm) + "|" + String(lastSpo2) + "|1";
  String tag = hmacHex(canonical);
  if (tag.length() != 64) { emitEvent("hmac_failure"); return; }
  JsonDocument doc;
  doc["device_id"] = DEVICE_ID;
  doc["session"] = session;
  doc["packet"] = sequence;
  doc["heart_rate_bpm"] = lastBpm;
  doc["spo2_percent"] = lastSpo2;
  doc["simulated"] = true;
  doc["mac"] = tag;
  serializeJson(doc, Serial);
  Serial.println();
}

void indicators(uint32_t now) {
  bool connected = hostSeen && now - lastHostAt < 5000 && session.length() == 32;
  bool alarm = localAlarm(now) || (connected && hostAlarm);
  digitalWrite(RED_PIN, alarm ? HIGH : LOW);
  digitalWrite(GREEN_PIN, connected && !alarm ? HIGH : LOW);
#if ENABLE_BUZZER
  // Logical drive for a VERIFIED 3.3V active buzzer MODULE input with driver.
  digitalWrite(BUZZER_PIN, alarm && (now % 800 < 160) ? HIGH : LOW);
#endif
#if ENABLE_OLED
  static uint32_t lastDraw = 0;
  if (!oledReady || now - lastDraw < 200) return;
  lastDraw = now;
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("MediSentinel");
  display.println("SIMULATED VITALS");
  display.print("HR: "); display.print(lastBpm); display.println(" BPM");
  display.print("SpO2: "); display.print(lastSpo2); display.println(" %");
  display.print("Packet: "); display.println(sequence);
  display.println(alarm ? "ALERT / LAB DEMO" : connected ? "HOST CONNECTED" : "WAITING FOR HOST");
  display.display();
#endif
}

void setup() {
  pinMode(RED_PIN, OUTPUT);
  pinMode(GREEN_PIN, OUTPUT);
  digitalWrite(RED_PIN, LOW);
  digitalWrite(GREEN_PIN, LOW);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
#if ENABLE_BUZZER
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
#endif
  Serial.begin(115200);
  inputLine.reserve(MAX_LINE);
  randomSeed(esp_random());
#if ENABLE_OLED
  Wire.begin(21, 22);
  Wire.setTimeOut(50);
  oledReady = display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
#endif
  emitEvent("device_ready_waiting_session");
}

void loop() {
  pollSerial();
  uint32_t now = millis();
  pollButton(now);
  sample(now);
  indicators(now);
  yield();
}
