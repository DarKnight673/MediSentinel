"""Generate a unique local lab key. Run before uploading the secure ESP32 sketch."""
from pathlib import Path
import os
import secrets

ROOT = Path(__file__).resolve().parent


def main():
    target = ROOT / ".local" / "lab_key.txt"
    target.parent.mkdir(exist_ok=True)
    if target.exists():
        key = target.read_text().strip()
        print("Reusing existing lab key. Keep it private.")
    else:
        key = secrets.token_hex(32)
        target.write_text(key + "\n")
        try:
            os.chmod(target, 0o600)
        except OSError:
            pass
        print("Created unique lab key (not printed).")
    header = ROOT / "firmware" / "MediSentinel_ESP32" / "secrets.h"
    header.parent.mkdir(parents=True, exist_ok=True)
    header.write_text('// Generated locally. Do not publish this file.\n#pragma once\nconst char* LAB_KEY = "' + key + '";\n')
    print("ESP32 secrets.h ready. Never add the key to the ESP8266.")


if __name__ == "__main__":
    main()
