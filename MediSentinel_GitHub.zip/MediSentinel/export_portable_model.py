"""Export an already-trained trusted sklearn pipeline to declarative JSON.

Only this conversion/retraining script requires joblib/scikit-learn. Dashboard
inference from its JSON output uses Python's standard library only.
"""
from pathlib import Path
import json
import platform

from ml_detector import FEATURE_NAMES, PORTABLE_FORMAT, validate_portable_model


def export_bundle(bundle, destination):
    import sklearn
    model = bundle["model"]
    scaler = model.named_steps["standardscaler"]
    svm = model.named_steps["oneclasssvm"]
    if svm.kernel != "rbf" or svm.support_vectors_.shape[1] != len(FEATURE_NAMES):
        raise ValueError("Only the trained four-feature RBF OneClassSVM is supported")
    portable = {k: v for k, v in bundle.items() if k != "model"}
    portable.update({"format": PORTABLE_FORMAT,
                     "inference_engine": "stdlib RBF",
                     "export_provenance": {"python": platform.python_version(), "sklearn": sklearn.__version__,
                                           "source": "Trusted local trained sklearn pipeline; no retraining during export"},
                     "parameters": {"scaler_mean": scaler.mean_.tolist(),
                                    "scaler_scale": scaler.scale_.tolist(),
                                    "support_vectors": svm.support_vectors_.tolist(),
                                    "dual_coef": svm.dual_coef_[0].tolist(),
                                    "gamma": float(svm._gamma)}})
    validate_portable_model(portable)
    destination = Path(destination)
    destination.write_text(json.dumps(portable, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return portable


if __name__ == "__main__":
    import joblib
    root = Path(__file__).resolve().parent
    target = root / "models" / "telemetry_novelty.json"
    export_bundle(joblib.load(root / "models" / "telemetry_novelty.joblib"), target)
    print(f"Exported the existing learned model to {target.name}")
