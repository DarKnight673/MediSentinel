# Portable learned-model inference verification

The existing trained StandardScaler + RBF OneClassSVM was exported to declarative
JSON without retraining, replacing parameters, or changing the calibration threshold.
Live inference now uses only Python's standard library. This remains a learned
machine-learning model: it evaluates the same 197 learned support vectors and
coefficients, with the same scaler and RBF gamma. It does not replace ML with rules.

Compared against scikit-learn on all 17,280 held-out benchmark rows plus
100 deterministic edge inputs: **zero anomaly-label mismatches** across
17,380 inputs. Maximum absolute raw-score difference was
1.07e-14; required tolerance was 1e-10. Public API scores retain their
existing six-decimal display rounding; labels use full-precision values. The
threshold and previously reported benchmark metrics are unchanged.

A fresh Python process deliberately blocked imports of joblib, NumPy, SciPy and
scikit-learn. Model loading and scoring succeeded, including HR=110, SpO2=94 after
77/97. Missing explicit paths remain unavailable. Invalid JSON parameters fail
closed and never fall back to joblib deserialization. Explicit JSON paths work.

The JSON contains only numeric parameters and provenance. Training/retraining and
export still require the research dependencies. Legacy joblib loading remains for
trusted files when corresponding JSON is absent; untrusted pickle/joblib artifacts
must never be loaded. Numerical equivalence was measured on the inputs above,
not formally proved for every floating-point input on every platform.

Run `python export_portable_model.py` to export an existing trusted joblib model.
`python train_evaluate.py` now regenerates both artifacts in the same run, preventing
stale JSON after retraining. Full machine-readable verification, hashes and formula
are in `portable_model_verification.json`.
