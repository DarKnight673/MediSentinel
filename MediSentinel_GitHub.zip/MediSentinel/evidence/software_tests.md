# Software verification evidence

Executed 2026-11-08T19:01:44.900920+00:00 using Python 3.12.14.

**26/26 passed; 0 failures, 0 errors, 0 skipped.**

Run from the extracted MediSentinel_Research folder:

```powershell
python -m unittest discover -s tests -v
```

To regenerate JSON and this evidence file: `python tests/run_evidence.py`.

Coverage: strict canonical HMAC authentication; signed sequence gaps; replay and old-counter rejection; fresh-session old-message rejection; tampering, unknown identity, schema/type/bounds/nonfinite rejection; rejected packets excluded from graphs and ML; explicit legacy UNVERIFIED mode with ML disabled; manual overlay distinct from telemetry; ML unavailability; HTTP local-action token, Origin/Host restrictions, request-size limits, cache/security headers and actual template rendering.

The POSIX PTY integration test runs the actual pyserial reader/writer with two emulated serial streams. It validates authenticated SESSION and ALARM commands, telemetry acceptance, CAPTURE forwarding, and rejected replay/altered/spoof outputs returned by the emulated second node. This is simulated serial integration, not ESP32/ESP8266 hardware verification. On Windows, the PTY-only test is skipped; the other tests still run.

**Hardware status:** Arduino sketches have not been compiled here. Firmware upload, physical USB, wiring, LEDs, OLED, buzzer and physical button remain unverified until Saif tests them. The ML benchmark is documented separately in `metrics.json` and `evaluation.md`; these tests do not establish clinical or real-world attack performance.

During verification, nonfinite-input audit logging and the serial-writer/engine lock acquisition order were corrected to prevent a malformed input crash and a possible connection-failure deadlock. Legacy numeric bounds are checked before conversion, preventing overflow on huge invalid integers.

## Actual test output

```text
test_crypto_rule_and_ml_alerts_are_distinct (test_system.EngineTests.test_crypto_rule_and_ml_alerts_are_distinct) ... ok
test_demo_attack_types_are_rejected (test_system.EngineTests.test_demo_attack_types_are_rejected) ... ok
test_invalid_input_with_audit_logging_does_not_crash (test_system.EngineTests.test_invalid_input_with_audit_logging_does_not_crash) ... ok
test_legacy_is_unverified_and_not_available_in_secure_mode (test_system.EngineTests.test_legacy_is_unverified_and_not_available_in_secure_mode) ... ok
test_manual_overlay_does_not_modify_telemetry (test_system.EngineTests.test_manual_overlay_does_not_modify_telemetry) ... ok
test_rejected_packets_do_not_poison_ml_or_graph (test_system.EngineTests.test_rejected_packets_do_not_poison_ml_or_graph) ... ok
test_unavailable_model_is_explicit (test_system.EngineTests.test_unavailable_model_is_explicit) ... ok
test_api_bad_body_size_and_action (test_system.HttpTests.test_api_bad_body_size_and_action) ... ok
test_clear_and_model_demo_modes (test_system.HttpTests.test_clear_and_model_demo_modes) ... ok
test_cross_origin_and_untrusted_host_blocked (test_system.HttpTests.test_cross_origin_and_untrusted_host_blocked) ... ok
test_dashboard_template_renders_local_controls (test_system.HttpTests.test_dashboard_template_renders_local_controls) ... ok
test_manual_api_requires_token (test_system.HttpTests.test_manual_api_requires_token) ... ok
test_status_no_cache_and_security_headers (test_system.HttpTests.test_status_no_cache_and_security_headers) ... ok
test_altered_telemetry_does_not_advance_counter (test_system.SecurityTests.test_altered_telemetry_does_not_advance_counter) ... ok
test_command_authentication_domain_separation (test_system.SecurityTests.test_command_authentication_domain_separation) ... ok
test_new_session_rejects_valid_old_signature (test_system.SecurityTests.test_new_session_rejects_valid_old_signature) ... ok
test_replays_and_older_counters (test_system.SecurityTests.test_replays_and_older_counters) ... ok
test_schema_types_bounds_and_nonfinite (test_system.SecurityTests.test_schema_types_bounds_and_nonfinite) ... ok
test_unknown_device_rejected (test_system.SecurityTests.test_unknown_device_rejected) ... ok
test_valid_canonical_hmac_and_sequence_gaps (test_system.SecurityTests.test_valid_canonical_hmac_and_sequence_gaps) ... ok
test_limit_and_multiple_records (test_system.SerialFramingTests.test_limit_and_multiple_records) ... ok
test_oversized_complete_record_then_valid_same_chunk (test_system.SerialFramingTests.test_oversized_complete_record_then_valid_same_chunk) ... ok
test_oversized_record_drains_across_timeouts_and_recovers (test_system.SerialFramingTests.test_oversized_record_drains_across_timeouts_and_recovers) ... ok
test_partial_record_survives_empty_timeout_chunks (test_system.SerialFramingTests.test_partial_record_survives_empty_timeout_chunks) ... ok
test_delayed_fragments_and_oversized_suffix_recovery (test_system.SimulatedSerialIntegrationTests.test_delayed_fragments_and_oversized_suffix_recovery) ... ok
test_two_usb_streams_handshake_capture_and_attack_results (test_system.SimulatedSerialIntegrationTests.test_two_usb_streams_handshake_capture_and_attack_results) ... ok

----------------------------------------------------------------------
Ran 26 tests in 1.930s

OK
```
