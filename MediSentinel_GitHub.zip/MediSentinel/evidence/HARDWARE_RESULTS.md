# Physical verification record - 8 November 2026

**Verified:** two-board secure USB lab. **Pending:** LEDs, physical button, OLED and buzzer wiring and response.

Saif performed USB connections, Arduino compilation/uploads and Python launch on his Windows laptop. The assistant observed the running gateway through the connected browser. The machine-readable record is `laptop_hardware_checks_2026-11-08.json`.

| Item | Recorded value |
|---|---|
| ESP32 | Development board, COM3 at 115200; exact core/version not recorded |
| ESP8266 | NodeMCU ESP-12E, COM8 at 115200; exact core/version not recorded |
| Gateway | Secure mode, http://127.0.0.1:5004/ |
| Telemetry | Simulated; no medical sensors |
| Model runtime | One-Class SVM, `stdlib RBF`, available in secure mode |
| Last accepted sample | Packet 145, HR 84, SpO2 97, authenticated, model anomaly false |
| Last model score / threshold | -21.544539 / -18.598909005302424 |
| ArduinoJson / OLED / buzzer details | Version/controller/rating not recorded; OLED/buzzer not wired |

| Check | Status | Observation / remaining work |
|---|---|---|
| Original Arduino sketch backup | Not evidenced | Confirm separately if saved |
| ESP32 compilation and upload | Completed by user | Secure sketch running on COM3 |
| Matching host/device HMAC key | Demonstrated | Authenticated telemetry accepted; never publish key |
| Secure SESSION and authenticated packets | Observed | Snapshot: 145 accepted/authenticated packets |
| ESP8266 compilation and upload | Completed by user | Test node running on COM8 |
| Actual ESP8266 replay | Observed twice | `replay` rejected from attacker USB |
| Actual ESP8266 altered telemetry | Observed twice after repair | `bad_mac` rejected from attacker USB |
| Actual ESP8266 spoofed identity | Observed twice | `unknown_device` rejected from attacker USB |
| Browser manual red banner | Previously observed | Earlier software-mode browser check; no peripheral response implied |
| ML active on hardware simulation | Observed | One flag among 145 accepted normal simulated samples; not a false-alarm-rate estimate |
| Red LED and resistor | Pending | Unwired/unverified |
| Green LED normal link | Pending | Unwired/unverified |
| Physical button 15-second demonstration | Pending | Unwired/unverified; no deliberate physical-button anomaly observed |
| OLED simulated label/alert | Pending / optional | Unwired/unverified |
| Suitable buzzer | Pending / optional | Unwired/unverified; keep disabled until identified |
| ESP32 reset/reconnect fresh session | Not systematically tested | Record a deliberate trial |
| 20-minute stability and recovery | Pending | Record a timed run |

## Observed post-repair adversarial trials

| Attempt | Expected | Observed | Unix timestamp, milliseconds |
|---|---|---|---:|
| Altered | bad_mac | bad_mac | 1794165085637 |
| Replay | replay | replay | 1794165102985 |
| Spoof | unknown_device | unknown_device | 1794165105418 |
| Altered | bad_mac | bad_mac | 1794165151741 |
| Replay | replay | replay | 1794165153961 |
| Spoof | unknown_device | unknown_device | 1794165155103 |

All six rejections came from the **attacker** input. Snapshot counts: received 151, accepted/authenticated 145, rejected 6, with 2 `bad_mac`, 2 `replay` and 2 `unknown_device`. Two trials per case demonstrate functionality only, not a real-world rejection rate.

## Repair and unresolved observations

Before repair, two altered trials produced `invalid_json/schema` instead of `bad_mac`. They are excluded from successful authentication-check demonstrations. The user applied `MediSentinel_Serial_Fix.py`; the current bounded framer retains partial JSON across read timeouts and drains oversized records. Delayed-fragment/oversize recovery now has software tests.

Repeated `capture_ready` notices were observed; their cause is not established. They are informational messages excluded from accepted telemetry and ML. No Wi-Fi attack traffic was generated.

Keep held-out synthetic ML results in `metrics.json` separate from physical USB observations. Do not describe simulated vitals as measurements or claim a peripheral response before recording it.
