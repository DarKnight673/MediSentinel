"""MediSentinel local research gateway. Run --demo first. See START_HERE.md."""
import argparse
from collections import Counter, deque
import copy
import json
import math
from pathlib import Path
import random
import secrets
import threading
import time

from flask import Flask, jsonify, render_template, request
from security import Verifier, signed_packet, session_command, alarm_command

ROOT = Path(__file__).resolve().parent


def demo_rules(p):
    rules = []
    if p["heart_rate_bpm"] < 50 or p["heart_rate_bpm"] > 120:
        rules.append("Example HR threshold")
    if p["spo2_percent"] < 92:
        rules.append("Example SpO2 threshold")
    return rules


class Engine:
    def __init__(self, key, mode="demo", detector=None, log_dir=None):
        self.lock = threading.RLock()
        self.mode = mode
        self.verifier = Verifier(key)
        self.detector = detector
        self.latest = None
        self.history = deque(maxlen=120)
        self.events = deque(maxlen=60)
        self.counts = Counter()
        self.last_capture = None
        self.last_seen = 0
        self.manual_until = 0
        self.security_until = 0
        self.ml_until = 0
        self.anomaly_until = 0
        self.connections = {"device": "Software generator" if mode == "demo" else "Waiting for USB", "attacker": "Not connected"}
        self.on_capture = None
        self.on_attack = None
        self.log_path = None
        self.log_error = None
        if log_dir:
            Path(log_dir).mkdir(parents=True, exist_ok=True)
            self.log_path = Path(log_dir) / (time.strftime("session_%Y%m%d_%H%M%S") + "_" + secrets.token_hex(3) + ".jsonl")

    def event(self, category, title, detail=""):
        # caller owns the RLock; event values are rendered with textContent.
        item = {"timestamp": int(time.time() * 1000), "category": category, "title": title, "detail": detail}
        self.events.appendleft(item)
        self.log({"type": "event", **item})

    def log(self, item):
        if self.log_path:
            try:
                try:
                    encoded = json.dumps(item, allow_nan=False)
                except (ValueError, TypeError):
                    # Invalid/nonfinite input must still leave an audit record.
                    encoded = json.dumps({"type": "invalid_input_log", "detail": repr(item)[:4096]})
                with self.log_path.open("a", encoding="utf-8") as f:
                    f.write(encoded + "\n")
            except OSError as exc:
                self.log_error = str(exc)

    def new_session(self):
        with self.lock:
            session = self.verifier.new_session()
            self.latest = None
            self.last_capture = None
            self.last_seen = 0
            self.event("system", "Fresh authenticated session", "Previous-session packets will be rejected.")
            return session

    def ingest(self, payload, source="device", legacy=False):
        with self.lock:
            self.counts["received"] += 1
            if legacy:
                if self.mode != "legacy" or source != "device" or not isinstance(payload, dict):
                    ok, reason = False, "schema"
                else:
                    ok = all(type(payload.get(k)) in (int, float) and lo <= payload[k] <= hi and math.isfinite(payload[k])
                             for k, lo, hi in (("heart_rate_bpm", 0, 300), ("spo2_percent", 0, 100)))
                    reason = "legacy_unverified" if ok else "schema"
                if ok:
                    payload = {"device_id": str(payload.get("device_id", "LEGACY"))[:64], "packet": str(payload.get("packet", "?"))[:24],
                               "heart_rate_bpm": payload["heart_rate_bpm"], "spo2_percent": payload["spo2_percent"], "simulated": True}
            else:
                ok, reason = self.verifier.verify(payload)
            now = time.time()
            if not ok:
                self.counts["rejected"] += 1
                self.counts[reason] += 1
                self.security_until = time.monotonic() + 10
                self.event("security", "REJECTED: " + reason.replace("_", " ").upper(), f"Input: {source}. Packet excluded from telemetry and ML.")
                self.log({"type": "rejected", "timestamp": now, "source": source, "reason": reason, "packet": payload})
                return False, reason
            previous = self.latest if self.latest and now - self.last_seen < 5 else None
            ml = self.detector.score(payload["heart_rate_bpm"], payload["spo2_percent"], previous) if self.detector and not legacy else {"available": False, "anomaly": False, "score": None, "threshold": None}
            point = {**payload, "timestamp": int(now * 1000), "source": source, "authenticated": not legacy,
                     "rules": demo_rules(payload), "ml": ml}
            point.pop("mac", None)
            self.latest = point
            self.last_seen = now
            self.history.append(point)
            self.counts["accepted"] += 1
            self.counts["unverified" if legacy else "authenticated"] += 1
            if ml.get("anomaly"):
                self.ml_until = time.monotonic() + 5
                self.counts["ml_flags"] += 1
                if previous is None or not previous["ml"].get("anomaly"):
                    self.event("ml", "ML statistical anomaly", "The trained novelty model flagged accepted simulated telemetry. Cause is unproven.")
            if point["rules"] and (previous is None or previous["rules"] != point["rules"]):
                self.event("threshold", "Example vital-sign rule", "; ".join(point["rules"]))
            self.log({"type": "accepted", **point})
            if not legacy:
                self.last_capture = copy.deepcopy(payload)
                if self.on_capture:
                    self.on_capture(payload)
            return True, reason

    def manual_alert(self):
        with self.lock:
            self.manual_until = time.monotonic() + 12
            self.event("manual", "MANUAL DEMO ALERT", "Explicit 12-second operator test. This does not prove attack or ML detection.")

    def attack(self, name):
        with self.lock:
            if name not in ("replay", "altered", "spoof"):
                return False, "Unknown test"
            if self.mode != "demo":
                if self.mode == "legacy" or not self.on_attack:
                    return False, "Connect the ESP8266 with --attacker-port in secure mode, or use --demo."
                if not self.last_capture:
                    return False, "Waiting for an authenticated capture"
                sent = self.on_attack(name)
                if sent:
                    self.event("lab", "Requested ESP8266 " + name, "Awaiting bytes from the physical test node; request alone is not a detection result.")
                return bool(sent), "Requested" if sent else "ESP8266 unavailable"
            if not self.last_capture:
                return False, "Waiting for a signed packet"
            packet = copy.deepcopy(self.last_capture)
            if name == "altered":
                packet["heart_rate_bpm"] = 110 if packet["heart_rate_bpm"] != 110 else 111
            elif name == "spoof":
                packet["device_id"] = "FORGED-DEVICE"
            self.event("lab", "Software test: " + name, "In-process test; ESP8266 is not involved in demo mode.")
            return self.ingest(packet, "software_attack")

    def snapshot(self):
        with self.lock:
            now = time.monotonic()
            fresh = bool(self.last_seen and time.time() - self.last_seen < 5)
            alerts = []
            if now < self.manual_until:
                alerts.append("MANUAL DEMO - operator-triggered")
            if now < self.security_until:
                alerts.append("SECURITY RULE - rejected packet")
            if now < self.ml_until:
                alerts.append("ML - statistical telemetry anomaly")
            if fresh and self.latest["rules"]:
                alerts.append("EXAMPLE THRESHOLD - simulated vital signs")
            return {"mode": self.mode, "receiving": fresh, "latest": self.latest, "history": list(self.history),
                    "events": list(self.events), "counts": dict(self.counts), "alerts": alerts,
                    "alarm": bool(alerts), "connections": dict(self.connections), "log_error": self.log_error,
                    "ml_info": getattr(self.detector, "info", {"available": False}),
                    "attacks_available": self.mode == "demo" or bool(self.on_attack)}


def create_app(engine):
    app = Flask(__name__, template_folder=str(ROOT / "templates"))
    app.config["MAX_CONTENT_LENGTH"] = 2048
    token = secrets.token_urlsafe(32)

    @app.before_request
    def local_only():
        if request.host.split(":")[0] not in ("localhost", "127.0.0.1"):
            return jsonify(error="Use localhost or 127.0.0.1"), 403
        if request.method != "GET":
            if not secrets.compare_digest(request.headers.get("X-MediSentinel-Local", ""), token):
                return jsonify(error="Local action token required"), 403
            origin = request.headers.get("Origin")
            if origin and origin != request.host_url.rstrip("/"):
                return jsonify(error="Cross-origin action blocked"), 403

    @app.after_request
    def headers(response):
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"
        return response

    @app.get("/")
    def index():
        return render_template("dashboard.html", local_token=token)

    @app.get("/api/status")
    def status():
        return jsonify(engine.snapshot())

    @app.post("/api/action")
    def action():
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify(error="JSON object required"), 400
        name = data.get("action")
        if name == "manual":
            engine.manual_alert()
        elif name == "clear":
            with engine.lock:
                engine.manual_until = engine.security_until = engine.ml_until = 0
                engine.event("manual", "Transient alerts cleared", "Continuing rules and new detections can reactivate alarms.")
        elif name == "ml_demo":
            if engine.mode != "demo":
                return jsonify(error="Signed software anomaly is available in --demo only"), 409
            with engine.lock:
                engine.anomaly_until = time.monotonic() + 12
                engine.event("lab", "Signed synthetic anomaly enabled", "12 seconds of HR110 / SpO2 94; ML result follows independently.")
        elif name in ("replay", "altered", "spoof"):
            result, reason = engine.attack(name)
            # A demo packet being rejected is a successfully executed test.
            if engine.mode != "demo" and not result:
                return jsonify(error=reason), 409
            return jsonify(ok=True, result=reason)
        else:
            return jsonify(error="Unknown action"), 400
        return jsonify(ok=True)

    return app


def demo_loop(engine, stop):
    n = 0
    rng = random.Random(20261108)
    while not stop.is_set():
        n += 1
        with engine.lock:
            anomaly = time.monotonic() < engine.anomaly_until
            hr = 110 if anomaly else round(77 + 7 * math.sin(n / 7) + rng.uniform(-2, 2))
            spo2 = 94 if anomaly else round(97 + math.sin(n / 11) + rng.uniform(-.5, .5))
            p = signed_packet(engine.verifier.key, engine.verifier.session, n, hr, spo2)
        engine.ingest(p, "software_generator")
        stop.wait(1)


class BoundedLineFramer:
    """Assemble newline records across serial timeouts with bounded memory.

    ``None`` marks one oversized record. Its remaining bytes are discarded
    until newline, even if a timeout occurs while draining that record.
    """
    def __init__(self, limit=2048):
        self.limit = limit
        self.pending = bytearray()
        self.discarding = False

    def feed(self, chunk):
        segments = chunk.split(b"\n")
        for index, segment in enumerate(segments):
            complete = index < len(segments) - 1
            if self.discarding:
                if complete:
                    self.discarding = False
                continue
            if len(self.pending) + len(segment) > self.limit:
                self.pending.clear()
                self.discarding = not complete
                yield None
                continue
            self.pending.extend(segment)
            if complete:
                line = bytes(self.pending)
                self.pending.clear()
                yield line


class SerialLab:
    def __init__(self, engine, device_port, attacker_port, baud):
        self.engine, self.device_port, self.attacker_port, self.baud = engine, device_port, attacker_port, baud
        self.writer_lock = threading.Lock()
        self.ports = {}

    def write(self, role, command):
        error = None
        with self.writer_lock:
            port = self.ports.get(role)
            if port is None:
                return False
            try:
                port.write(command.encode("ascii"))
                return True
            except Exception as exc:
                # A failed lab connection must not stop verified device processing.
                error = str(exc)
        # Never acquire the engine lock while holding writer_lock: ingest's
        # capture callback takes them in the opposite order.
        with self.engine.lock:
            self.engine.connections[role] = error
        return False

    def capture(self, packet):
        self.write("attacker", "CAPTURE " + json.dumps(packet, separators=(",", ":")) + "\n")

    def attack(self, name):
        return self.write("attacker", "ATTACK " + name + "\n")

    def reader(self, role, name, stop):
        import serial
        engine = self.engine
        while not stop.is_set():
            try:
                with serial.Serial(name, self.baud, timeout=.25, write_timeout=.5) as port:
                    with self.writer_lock:
                        self.ports[role] = port
                    with engine.lock:
                        engine.connections[role] = f"{name} @ {self.baud}"
                    next_handshake = 0
                    if role == "device" and engine.mode != "legacy":
                        engine.new_session()
                    last_telemetry = time.monotonic()
                    framer = BoundedLineFramer()
                    while not stop.is_set():
                        now = time.monotonic()
                        if role == "device" and engine.mode != "legacy" and now >= next_handshake:
                            if now - last_telemetry > 8:
                                engine.new_session()
                                last_telemetry = now
                            self.write(role, session_command(engine.verifier.key, engine.verifier.session))
                            next_handshake = now + 2
                        if role == "device" and engine.mode != "legacy":
                            self.write(role, alarm_command(engine.verifier.key, engine.verifier.session, engine.snapshot()["alarm"]))
                        # Timeout means no more bytes yet, not end-of-record.
                        # Read a bounded chunk and keep partial records until '\n'.
                        chunk = port.read(max(1, min(port.in_waiting, 2048)))
                        for line in framer.feed(chunk):
                            if line is None:
                                engine.ingest({"oversized": True}, role)
                                continue
                            if not line.strip():
                                continue
                            try:
                                payload = json.loads(line)
                            except (ValueError, UnicodeDecodeError):
                                # ESP boot logs are not telemetry. JSON-like malformed input is audited.
                                if line.lstrip().startswith((b"{", b"[")):
                                    engine.ingest({"invalid_json": True}, role)
                                continue
                            if isinstance(payload, dict) and payload.get("event") == "manual_button" and role == "device":
                                # This event is a local convenience signal, never called authenticated telemetry.
                                with engine.lock:
                                    engine.event("manual", "Physical button test (USB event)", "Unsigned local event; telemetry still requires a valid signature.")
                                continue
                            if isinstance(payload, dict) and "status" in payload:
                                with engine.lock:
                                    engine.event("lab", role + " node status", str(payload["status"])[:120])
                                continue
                            accepted, _ = engine.ingest(payload, role, legacy=engine.mode == "legacy" and role == "device")
                            if accepted and role == "device":
                                last_telemetry = time.monotonic()
            except (serial.SerialException, OSError) as exc:
                with engine.lock:
                    engine.connections[role] = f"{name}: {exc}"
            finally:
                with self.writer_lock:
                    self.ports.pop(role, None)
            stop.wait(2)

    def start(self, stop):
        if self.attacker_port:
            self.engine.on_capture = self.capture
            self.engine.on_attack = self.attack
        for role, port in (("device", self.device_port), ("attacker", self.attacker_port)):
            if port:
                threading.Thread(target=self.reader, args=(role, port, stop), daemon=True).start()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--demo", action="store_true")
    modes.add_argument("--port", help="Secure ESP32 port, e.g. COM3")
    modes.add_argument("--legacy-port", help="Original unsigned firmware, explicitly UNVERIFIED")
    parser.add_argument("--attacker-port", help="ESP8266 USB port; secure mode only")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--http-port", type=int, default=5003)
    args = parser.parse_args()
    if args.attacker_port and (not args.port or args.port == args.attacker_port):
        parser.error("--attacker-port needs --port and a different COM port")
    mode = "demo" if args.demo else "legacy" if args.legacy_port else "secure"
    key_path = ROOT / ".local" / "lab_key.txt"
    if mode == "secure" and not key_path.exists():
        parser.error("Run python setup_lab.py, then upload generated ESP32 firmware first.")
    key = key_path.read_text().strip() if key_path.exists() else secrets.token_hex(32)
    try:
        from ml_detector import MLDetector
        detector = MLDetector()
    except Exception as exc:
        print("ML unavailable:", exc)
        detector = None
    engine = Engine(key, mode, detector, ROOT / "logs")
    if not getattr(detector, "available", False):
        print("ML model not active. Run python train_evaluate.py. Security rules remain available.")
    stop = threading.Event()
    if mode == "demo":
        threading.Thread(target=demo_loop, args=(engine, stop), daemon=True).start()
    else:
        SerialLab(engine, args.port or args.legacy_port, args.attacker_port, args.baud).start(stop)
    print(f"MediSentinel: http://127.0.0.1:{args.http_port} | {mode.upper()} | ALL VITAL SIGNS SIMULATED")
    try:
        create_app(engine).run(host="127.0.0.1", port=args.http_port, debug=False, use_reloader=False)
    finally:
        stop.set()


if __name__ == "__main__":
    main()
