"""Install this separate project locally, test it and start a visible console.

Only runs setup when invoked as a program. Existing processes and firmware are
left in place. Logs are local; nothing is automatically uploaded.
"""
from pathlib import Path
import datetime
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parent


def available_port(start=5004):
    for port in range(start, start + 20):
        with socket.socket() as probe:
            try:
                probe.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("Ports 5004-5023 are occupied. Stop an unused local server.")


def run_logged(command, logfile, label):
    print("\n" + label, flush=True)
    logfile.write("\n" + label + "\n")
    logfile.flush()
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    for line in process.stdout:
        print(line, end="", flush=True)
        logfile.write(line)
        logfile.flush()
    if process.wait() != 0:
        raise RuntimeError(label + " failed. The full output is in setup.log.")


def open_code():
    # Use the actual application binary. Avoid shell command interpolation.
    options = [Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Microsoft VS Code/Code.exe",
               Path(os.environ.get("ProgramFiles", "C:/Program Files")) / "Microsoft VS Code/Code.exe"]
    for candidate in options:
        if candidate.is_file():
            try:
                subprocess.Popen([str(candidate), "--new-window", str(ROOT)])
                return True
            except OSError:
                # Opening an optional editor must not invalidate a working setup.
                continue
    return False


def main():
    if os.name != "nt":
        raise RuntimeError("This launcher is for Windows. Use START_HERE.md on other systems.")
    if not (3, 10) <= sys.version_info[:2] < (3, 14):
        raise RuntimeError("Use installed Python 3.10-3.13, preferably 3.12. No system settings were changed.")
    started = datetime.datetime.now().astimezone().isoformat()
    vpython = ROOT / ".venv/Scripts/python.exe"
    evidence = ROOT / "evidence/laptop"
    evidence.mkdir(parents=True, exist_ok=True)
    with (ROOT / "setup.log").open("a", encoding="utf-8") as log:
        print("MediSentinel: separate laptop installation\nFolder: " + str(ROOT), flush=True)
        print("Existing dashboards, SAIFMONITOR and ESP32 firmware stay in place.", flush=True)
        if not vpython.is_file():
            run_logged([sys.executable, "-m", "venv", str(ROOT / ".venv")], log, "1/5 Creating project environment")
        run_logged([str(vpython), "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")], log, "2/5 Installing dependencies from package registry")
        run_logged([str(vpython), "train_evaluate.py"], log, "3/5 Training and evaluating local model")
        # Keep the packaged Linux evidence as its original observation; laptop
        # checks have their own record and do not overwrite that provenance.
        run_logged([str(vpython), "laptop_check.py"], log, "4/5 Testing this laptop and checking COM3")
        run_logged([str(vpython), "setup_lab.py"], log, "5/5 Preparing local key for later secure firmware upload")
    check = json.loads((evidence / "laptop_verification.json").read_text(encoding="utf-8"))
    serial_ok = check["serial_probe"].get("legacy_json_observed", False)
    mode = ["--legacy-port", "COM3"] if serial_ok else ["--demo"]
    port = available_port()
    command = [str(vpython), str(ROOT / "medisentinel_secure.py"), *mode, "--http-port", str(port)]
    child = subprocess.Popen(command, cwd=ROOT, creationflags=subprocess.CREATE_NEW_CONSOLE)
    url = f"http://127.0.0.1:{port}"
    for _ in range(60):
        if child.poll() is not None:
            raise RuntimeError("Dashboard exited. Read its console and setup.log.")
        try:
            with urllib.request.urlopen(url + "/api/status", timeout=1) as response:
                status = json.load(response)
            break
        except (OSError, ValueError):
            time.sleep(.5)
    else:
        raise RuntimeError("Dashboard did not respond within 30 seconds. Read its visible console.")
    code_opened = open_code()
    webbrowser.open(url)
    summary = {
        "started_local": started, "completed_local": datetime.datetime.now().astimezone().isoformat(),
        "project_folder": str(ROOT), "dashboard_url": url, "server_pid": child.pid,
        "mode": status["mode"], "vscode_opened": code_opened,
        "firmware_uploaded": False, "physical_wiring_verified": False,
        "note": "Local setup only. ESP8266 not connected. Existing processes were not terminated."
    }
    (evidence / "setup_result.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("\nSETUP COMPLETE: " + url, flush=True)
    print("Mode: " + status["mode"].upper(), flush=True)
    if not serial_ok:
        print("COM3 was unavailable or no valid old-format telemetry was observed.\nThe new dashboard is running a SIGNED SOFTWARE DEMO. No existing programs were stopped.", flush=True)
    else:
        print("Original ESP32 telemetry observed; legacy mode is UNVERIFIED and ML is disabled.\nUse START_SIGNED_DEMO.cmd to test ML separately.", flush=True)
    print("Laptop evidence: " + str(evidence), flush=True)
    print("Secure firmware upload and physical wiring still require local verification.", flush=True)
    if not code_opened:
        print("Open this project folder manually in VS Code: " + str(ROOT), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\nSETUP STOPPED: " + str(exc), file=sys.stderr, flush=True)
        sys.exit(1)
