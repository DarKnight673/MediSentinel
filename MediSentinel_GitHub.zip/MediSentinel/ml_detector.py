"""Local learned telemetry anomaly scoring; independent of authentication rules.

The portable JSON model uses only Python's standard library for live inference.
It contains the same learned scaler, support vectors and RBF coefficients as the
scikit-learn model. Training/retraining still requires the research dependencies.
Legacy joblib loading is supported only for trusted artifacts; pickle can execute
code. When a corresponding JSON exists it is validated and preferred.
"""
from pathlib import Path
import json
import math

FEATURE_NAMES = ["heart_rate_bpm", "spo2_percent", "abs_delta_hr", "abs_delta_spo2"]
DEFAULT_MODEL_PATH = Path(__file__).resolve().parent / "models" / "telemetry_novelty.joblib"
PORTABLE_FORMAT = "medisentinel-oneclasssvm-rbf-v1"


def feature_vector(heart_rate_bpm, spo2_percent, previous=None):
    """Identical training/live features; first accepted sample uses zero deltas."""
    hr, spo2 = float(heart_rate_bpm), float(spo2_percent)
    if not all(math.isfinite(x) for x in (hr, spo2)):
        raise ValueError("Telemetry features must be finite")
    delta_hr = abs(hr - float(previous["heart_rate_bpm"])) if previous else 0.0
    delta_spo2 = abs(spo2 - float(previous["spo2_percent"])) if previous else 0.0
    features = [hr, spo2, delta_hr, delta_spo2]
    if not all(math.isfinite(x) for x in features):
        raise ValueError("Telemetry features must be finite")
    return features


def _numeric(value):
    if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
        raise ValueError("Portable model parameters must be finite numbers")
    return float(value)


def _vector(value, length):
    if not isinstance(value, list) or len(value) != length:
        raise ValueError("Portable model parameter dimensions mismatch")
    return [_numeric(x) for x in value]


def validate_portable_model(bundle):
    """Validate the small declarative format without executing serialized code."""
    if not isinstance(bundle, dict) or bundle.get("format") != PORTABLE_FORMAT:
        raise ValueError("Unsupported portable model format")
    if bundle.get("feature_names") != FEATURE_NAMES or bundle.get("algorithm") != "OneClassSVM":
        raise ValueError("Model feature schema or algorithm mismatch")
    p = bundle.get("parameters")
    if not isinstance(p, dict):
        raise ValueError("Portable model parameters missing")
    mean = _vector(p.get("scaler_mean"), 4)
    scale = _vector(p.get("scaler_scale"), 4)
    if any(x <= 0 for x in scale):
        raise ValueError("Portable scaler scale must be positive")
    support = p.get("support_vectors")
    if not isinstance(support, list) or not 1 <= len(support) <= 10000:
        raise ValueError("Portable model support-vector count invalid")
    support = [_vector(row, 4) for row in support]
    dual = _vector(p.get("dual_coef"), len(support))
    gamma = _numeric(p.get("gamma"))
    if gamma <= 0:
        raise ValueError("Portable RBF gamma must be positive")
    _numeric(bundle.get("threshold"))
    # Read provenance without requiring the original training packages at runtime.
    return {"mean": mean, "scale": scale, "support": support, "dual": dual, "gamma": gamma}


def portable_anomaly_score(features, parameters):
    """Negative score_samples: -sum_i dual_i * exp(-gamma*||z-SV_i||²).

    scikit-learn OneClassSVM.score_samples removes the decision-function offset;
    therefore the intercept is deliberately absent from this kernel sum.
    """
    z = [(x - mean) / scale for x, mean, scale in zip(features, parameters["mean"], parameters["scale"])]
    total = 0.0
    for support, coefficient in zip(parameters["support"], parameters["dual"]):
        distance = 0.0
        for x, y in zip(z, support):
            difference = x - y
            distance += difference * difference
        total += coefficient * math.exp(-parameters["gamma"] * distance)
    return -total


class MLDetector:
    def __init__(self, model_path=DEFAULT_MODEL_PATH):
        self.available = False
        self.model = None
        self._portable = None
        self.threshold = None
        self.info = {"algorithm": "OneClassSVM", "available": False,
                     "feature_names": FEATURE_NAMES, "error": "Model not loaded"}
        try:
            path = Path(model_path)
            portable_path = path if path.suffix.lower() == ".json" else path.with_suffix(".json")
            if portable_path.is_file():
                # A malformed JSON fails closed; it never triggers pickle fallback.
                if portable_path.stat().st_size > 5_000_000:
                    raise ValueError("Portable model exceeds size limit")
                bundle = json.loads(portable_path.read_text(encoding="utf-8"))
                self._portable = validate_portable_model(bundle)
                self.threshold = _numeric(bundle["threshold"])
                self.info = {k: v for k, v in bundle.items() if k != "parameters"}
                self.info["inference_engine"] = "stdlib RBF"
            else:
                if not path.is_file():
                    raise FileNotFoundError(f"Model artifact not found: {path.name}")
                import joblib
                import sklearn
                bundle = joblib.load(path)
                if bundle.get("feature_names") != FEATURE_NAMES:
                    raise ValueError("Model feature schema mismatch")
                if bundle.get("sklearn_version") != sklearn.__version__:
                    raise ValueError("scikit-learn version differs; retrain or supply portable JSON")
                self.model = bundle["model"]
                self.threshold = _numeric(bundle["threshold"])
                self.info = {k: v for k, v in bundle.items() if k != "model"}
                self.info["inference_engine"] = "scikit-learn"
            self.info.update({"available": True, "error": None})
            self.available = True
        except Exception as error:
            self.info["error"] = f"{type(error).__name__}: {error}. Restore models/telemetry_novelty.json or run python train_evaluate.py."

    def score(self, heart_rate_bpm, spo2_percent, previous=None):
        if not self.available:
            return {"available": False, "anomaly": False, "score": None,
                    "threshold": None, "error": self.info.get("error")}
        features = feature_vector(heart_rate_bpm, spo2_percent, previous)
        if self._portable is not None:
            score = portable_anomaly_score(features, self._portable)
        else:
            score = float(-self.model.score_samples([features])[0])
        return {"available": True, "anomaly": score > self.threshold,
                "score": round(score, 6), "threshold": self.threshold,
                "features": features}
